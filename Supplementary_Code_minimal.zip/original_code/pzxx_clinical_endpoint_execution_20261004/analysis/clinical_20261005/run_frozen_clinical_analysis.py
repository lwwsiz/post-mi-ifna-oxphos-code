"""Frozen selected-spectrum clinical analysis; local patient rows never printed.

Requires actual source admission, independent source PASS and pre-effect freeze.
Outputs all predeclared A/B/within-group/LOO results without choosing by P.
"""
from __future__ import annotations
import csv, hashlib, importlib.util, json, math, os, sys, traceback
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parents[1]
OLD = BASE.parent / 'pzxx_execution_20261004'
sys.path.insert(0,str(OLD/'_deps'))
import numpy as np
import scipy
from scipy.stats import rankdata, t

FROZEN = BASE/'protocol/CLINICAL_ANALYSIS_FROZEN_20261005.json'
FREEZE_HASH = 'b83981f7960cc4cd19dd04b2e428839b995c5338ab56dfd3b4bf5702ed3206fe'
CONDITIONAL = BASE/'protocol/scoring_preflight/CONDITIONAL_ANALYSIS_PROTOCOL_UNFROZEN.json'
CONDITIONAL_HASH = 'a9e0c72ae587352f96ce13607418d914b8799c9024be581acefe636092cb7d3b'
FULL = BASE/'candidate_sources/GSE11947_family_all_official_full.source'
LINK = BASE/'analysis/clinical_independent_20261005/SOURCE_GATE_INDEPENDENT.json'
ADMISSION = OUT/'SOURCE_CLINICAL_ADMISSION.json'
PREFLIGHT = BASE/'protocol/scoring_preflight/SCORING_PREFLIGHT_AGGREGATE.json'
PREFLIGHT_MODULE = BASE/'protocol/scoring_preflight/preflight_gse11947_scoring.py'
LOCAL = OUT/'LOCAL_ONLY'

def stamp(): return datetime.now(timezone.utc).isoformat()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def identity(path): return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}
def write(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def event(name,**fields):
    with (OUT/'CLINICAL_EXECUTION_EVENTS.jsonl').open('a',encoding='utf-8') as handle:
        handle.write(json.dumps({'time_utc':stamp(),'event':name,**fields},ensure_ascii=False)+'\n');handle.flush();os.fsync(handle.fileno())
def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def member_sha(values): return hashlib.sha256(('\n'.join(sorted(values))+'\n').encode()).hexdigest()

def read_patient_objects():
    records=[];current=None;table=False;header=False
    with FULL.open(encoding='utf-8') as handle:
        for raw in handle:
            line=raw.rstrip('\r\n')
            if line.startswith('^SAMPLE = '):
                current={'gsm':line.split(' = ',1)[1],'fields':{},'expression':{}};records.append(current)
            elif current is not None and line.startswith('!Sample_') and ' = ' in line:
                key,value=line.split(' = ',1);current['fields'].setdefault(key,[]).append(value)
            elif line=='!sample_table_begin': table=True;header=True
            elif line=='!sample_table_end':table=False
            elif table:
                if header: assert line=='ID_REF\tVALUE';header=False;continue
                probe,value=line.split('\t');assert probe not in current['expression']
                try: number=float(value)
                except ValueError:assert value.strip().casefold() in ('','na','nan','null');number=np.nan
                current['expression'][probe]=number
    assert not table and len(records)==32
    helper=load_module(OUT/'prepare_clinical_admission_and_freeze.py','clinical_metadata_helper')
    metadata=helper.sample_metadata(FULL)
    for record in records:record.update(metadata[record['gsm']])
    assert len({r['gsm'] for r in records})==len({r['subject'] for r in records})==32
    return records

def describe(values):
    arr=np.asarray(values,dtype=float)
    return {'n':len(arr),'mean':float(np.mean(arr)),'sample_SD':float(np.std(arr,ddof=1)) if len(arr)>1 else None,'min':float(np.min(arr)),'median':float(np.median(arr)),'max':float(np.max(arr))}

def fit_hc3(y,z,group=None):
    n=len(y);cols=[np.ones(n),np.asarray(z,dtype=float)]
    if group is not None:cols.append(np.asarray(group,dtype=float))
    X=np.column_stack(cols);rank=int(np.linalg.matrix_rank(X));p=X.shape[1]
    if rank!=p or n<=rank or not np.isfinite(X).all() or not np.isfinite(y).all():
        return {'status':'NON_ESTIMABLE','n':n,'rank_X':rank,'columns_X':p,'reason':'rank deficiency, nonfinite design/outcome or nonpositive residual df'}
    try:
        coefficients=np.linalg.lstsq(X,y,rcond=None)[0]
        bread=np.linalg.inv(X.T@X)
        residual=y-X@coefficients
        leverage=np.einsum('ij,jk,ik->i',X,bread,X)
        if np.any(leverage>=1-1e-12):return {'status':'NON_ESTIMABLE','n':n,'rank_X':rank,'reason':'HC3 leverage at1'}
        adjusted_square=(residual/(1-leverage))**2
        covariance=bread@((X.T*adjusted_square)@X)@bread
        variance=float(covariance[1,1])
        if not np.isfinite(variance) or variance<=0:return {'status':'NON_ESTIMABLE','n':n,'rank_X':rank,'reason':'nonpositive/nonfinite HC3 slope variance'}
        se=math.sqrt(variance);beta=float(coefficients[1]);df=n-rank;stat=beta/se
        crit=float(t.ppf(.975,df));pvalue=float(2*t.sf(abs(stat),df))
        sse=float(residual@residual);sst=float(np.sum((y-np.mean(y))**2));mse=sse/df
        cooks=(residual**2/(rank*mse))*leverage/(1-leverage)**2 if mse>0 else np.zeros(n)
        student=residual/np.sqrt(mse*(1-leverage)) if mse>0 else np.zeros(n)
        return {'status':'ESTIMATED','n':n,'rank_X':rank,'columns_X':p,'residual_df':df,
            'beta_LVEF_percentage_points_per_selected_sample_SD':beta,'HC3_SE':se,
            'CI95_low':beta-crit*se,'CI95_high':beta+crit*se,'t_statistic':stat,'P_two_sided_t_HC3':pvalue,
            'R_squared':1-sse/sst if sst>0 else None,
            'intercept':float(coefficients[0]),'group_B_intercept_difference':float(coefficients[2]) if group is not None else None,
            'model_diagnostics':{'condition_number_X':float(np.linalg.cond(X)),'leverage_min':float(np.min(leverage)),'leverage_max':float(np.max(leverage)),'leverage_sum':float(np.sum(leverage)),'residual_SD':float(np.std(residual,ddof=1)),'max_abs_internal_studentized_residual':float(np.max(np.abs(student))),'max_Cooks_distance':float(np.max(cooks)),'Cooks_above4_over_n_n':int(np.sum(cooks>4/n)),'diagnostic_count_not_exclusion_rule':True},
            'inference':'Complete-design HC3 with two-sided t approximation df=n-rank(X); conditional on selected sample and observed/working score; not selection bias repair'}
    except np.linalg.LinAlgError as error:
        return {'status':'NON_ESTIMABLE','n':n,'rank_X':rank,'reason':type(error).__name__}

def bh_two(fits):
    if any(x['status']!='ESTIMATED' for x in fits):return [None,None]
    ps=np.asarray([x['P_two_sided_t_HC3'] for x in fits]);order=np.argsort(ps)
    adjusted=np.minimum.accumulate((ps[order]*2/np.arange(1,3))[::-1])[::-1]
    output=np.empty(2);output[order]=np.minimum(adjusted,1)
    return [float(x) for x in output]

def main():
    assert sha(FROZEN)==FREEZE_HASH and sha(CONDITIONAL)==CONDITIONAL_HASH
    frozen=json.loads(FROZEN.read_text(encoding='utf-8'));assert frozen['frozen'] and not frozen['clinical_effects_previously_computed']
    link=json.loads(LINK.read_text(encoding='utf-8'));assert link['status'].startswith('PASS_') and all(link['checks'].values())
    admission=json.loads(ADMISSION.read_text(encoding='utf-8'));assert admission['status'].startswith('PASS_')
    for item in frozen['source_fingerprints']:assert sha(Path(item['path']))==item['sha256']
    assert sha(LINK)==frozen['freeze_provenance']['independent_source_gate']['sha256']
    assert sha(ADMISSION)==frozen['freeze_provenance']['source_admission']['sha256']
    all_input_paths=[FROZEN,CONDITIONAL,FULL,LINK,ADMISSION,PREFLIGHT,PREFLIGHT_MODULE]
    inputs_before=[identity(path) for path in all_input_paths]
    prior_events=[json.loads(line) for line in (OUT/'CLINICAL_EXECUTION_EVENTS.jsonl').read_text(encoding='utf-8').splitlines()]
    assert any(x['event']=='PROTOCOL_ACTUALLY_FROZEN_BEFORE_SCORES_OR_EFFECTS' and x['protocol']['sha256']==FREEZE_HASH for x in prior_events)
    assert not (OUT/'CLINICAL_RESULTS_AGGREGATE.json').exists(),'Do not silently replace a completed analysis'
    event('FROZEN_ANALYSIS_IMPLEMENTATION_STARTED',protocol_sha256=FREEZE_HASH,script=identity(Path(__file__)),independent_source_gate_sha256=sha(LINK),library_versions={'numpy':np.__version__,'scipy':scipy.__version__},clinical_effects_before_this_core_run=0)
    records=read_patient_objects()
    preflight=load_module(PREFLIGHT_MODULE,'frozen_mapping_helpers')
    approved,aliases=preflight.load_hgnc();platform,_,defs=preflight.read_family()
    mapping_status=Counter();gene_probes=defaultdict(list);mapping=[]
    probes=set(records[0]['expression'])
    for probe in sorted(probes):
        gene,status=preflight.map_annotation(platform[probe],approved,aliases);mapping_status[status]+=1
        mapping.append({'probe':probe,'raw_platform_symbol':platform[probe],'mapped_approved_gene':gene or '', 'mapping_status':status})
        if gene is not None:gene_probes[gene].append(probe)
    genes=sorted(gene_probes);matrix=np.empty((len(genes),32))
    for k,gene in enumerate(genes):
        for i,record in enumerate(records):
            values=np.asarray([record['expression'][p] for p in gene_probes[gene]],dtype=float);values=values[np.isfinite(values)]
            matrix[k,i]=np.median(values) if len(values) else np.nan
    gene_index={g:i for i,g in enumerate(genes)};observed=np.isfinite(matrix).sum(axis=1)
    frozen_sets=json.loads((OLD/'GENE_SETS_FROZEN.json').read_text(encoding='utf-8'))
    targets={name:set(frozen_sets[name]['declared_genes']) for name in ['IFNA','OXPHOS']}
    assert len(genes)==11611 and len(targets['IFNA'])==97 and len(targets['OXPHOS'])==200
    universes={'A':{genes[i] for i,n in enumerate(observed) if n==32},'B':{genes[i] for i,n in enumerate(observed) if n>=29}}
    source_preflight=json.loads(PREFLIGHT.read_text(encoding='utf-8'))
    for key,label in [('A','all_32_observed'),('B','at_least_29_observed')]:
        reference=source_preflight['universe_candidates'][label]
        assert len(universes[key])==reference['universe_genes_n'] and member_sha(universes[key])==reference['universe_sha256_sorted_newline']
        for name in targets:assert member_sha(targets[name]&universes[key])==reference['target_sets'][name]['universe_members_sha256_sorted_newline']
    scores={};definitions={};score_summary={};score_rows=[]
    for variant in ['A','B']:
        background=sorted(universes[variant]);working=matrix[[gene_index[g] for g in background],:].copy()
        missing=~np.isfinite(working);missing_before=int(missing.sum())
        if variant=='A':assert missing_before==0
        else:
            assert missing_before==5208
            for i in range(len(background)):
                mask=missing[i]
                if mask.any():working[i,mask]=np.median(working[i,~mask])
        assert np.isfinite(working).all()
        ranks=rankdata(working,axis=0,method='average');N=len(background);background_index={g:i for i,g in enumerate(background)}
        definitions[variant]={'background_genes':background,'background_genes_n':N,'background_sha256_sorted_newline':member_sha(background),'missing_entries_before_handling_n':missing_before,'imputation':'none' if variant=='A' else 'same-cohort gene median of observed aggregated log2(test/ref)','target_members':{},'role':'PRIMARY' if variant=='A' else 'WHOLE_SCORING_SCHEME_SENSITIVITY'}
        scores[variant]={};score_summary[variant]={}
        for name in ['IFNA','OXPHOS']:
            members=sorted(targets[name]&set(background));m=len(members);assert 0<m<N
            raw=(np.mean(ranks[[background_index[g] for g in members],:],axis=0)-(m+1)/2)/(N-m)-.5
            sd=float(np.std(raw,ddof=1));assert sd>0 and np.isfinite(sd)
            z=(raw-np.mean(raw))/sd;scores[variant][name]={'raw':raw,'z':z,'SD':sd,'mean':float(np.mean(raw))}
            assert np.all((raw>=-.5-1e-12)&(raw<=.5+1e-12))
            definitions[variant]['target_members'][name]={'declared_genes_n':len(targets[name]),'measured_genes_n':m,'genes':members,'member_sha256_sorted_newline':member_sha(members)}
            score_summary[variant][name]={'all_selected_patients':describe(raw),'original_groups':{g:describe(raw[[r['group']==g for r in records]]) for g in ['A','B']},'standardization':'selected all32 sample mean/SD ddof1; fixed for group and LOO analyses'}
    assert (len(universes['A']),len(universes['B']))==(7460,10533)
    assert [len(definitions[v]['target_members'][x]['genes']) for v,x in [('A','IFNA'),('A','OXPHOS'),('B','IFNA'),('B','OXPHOS')]]==[58,156,76,178]
    LOCAL.mkdir(exist_ok=True)
    (LOCAL/'LOCAL_ONLY_README.txt').write_text('本目录含去标识个体临床/表达/评分行，仅供已授权本地复核脚本。不得工具预览、发送外部模型/服务或直接公开。对话和交付引用仅用聚合结果。\n',encoding='utf-8')
    with (LOCAL/'PATIENT_SCORES_EF_LOCAL_ONLY.csv').open('w',encoding='utf-8',newline='') as handle:
        fields=['GSM','Subject_reference','Sample_reference','original_group','one_month_LVEF_percent','A_IFNA','A_IFNA_z','A_OXPHOS','A_OXPHOS_z','B_IFNA','B_IFNA_z','B_OXPHOS','B_OXPHOS_z'];writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
        for i,r in enumerate(records):
            row={'GSM':r['gsm'],'Subject_reference':r['subject'],'Sample_reference':r['sample'],'original_group':r['group'],'one_month_LVEF_percent':r['ef']}
            for variant in ['A','B']:
                for name in ['IFNA','OXPHOS']:row[f'{variant}_{name}']=float(scores[variant][name]['raw'][i]);row[f'{variant}_{name}_z']=float(scores[variant][name]['z'][i])
            writer.writerow(row)
    with (LOCAL/'PROBE_GENE_MAPPING_LOCAL_ONLY.csv').open('w',encoding='utf-8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(mapping[0]));writer.writeheader();writer.writerows(mapping)
    np.savez_compressed(LOCAL/'AGGREGATED_GENE_EXPRESSION_LOCAL_ONLY.npz',gene_symbols=np.asarray(genes),sample_GSM=np.asarray([r['gsm'] for r in records]),log2_test_reference=matrix)
    write(OUT/'SCORE_DEFINITION_AND_MEMBER_HASHES.json',{'frozen_protocol_sha256':FREEZE_HASH,'source_fingerprints':inputs_before,'mapping_status_counts':dict(mapping_status),'unique_approved_genes_n':len(genes),'declared_target_genes':{name:sorted(values) for name,values in targets.items()},'rank_formula':'Average-tie increasing rank; (mean_target_rank-(m+1)/2)/(N-m)-0.5','relative_reference_subset_boundary':True,'variants':definitions,'mapping_csv':identity(LOCAL/'PROBE_GENE_MAPPING_LOCAL_ONLY.csv'),'patient_identifiers_in_this_definition_file':False})
    write(OUT/'SCORE_DIAGNOSTICS_AGGREGATE.json',score_summary)
    event('FROZEN_SCORES_PREPARED_BEFORE_CORE_FITTING',protocol_sha256=FREEZE_HASH,score_definition_sha256=sha(OUT/'SCORE_DEFINITION_AND_MEMBER_HASHES.json'),local_scores_file_sha256=sha(LOCAL/'PATIENT_SCORES_EF_LOCAL_ONLY.csv'),A_background=7460,A_IFNA=58,A_OXPHOS=156,B_background=10533,B_IFNA=76,B_OXPHOS=178,core_clinical_effects_so_far=0)
    y=np.asarray([r['ef'] for r in records],dtype=float);group=np.asarray([r['group']=='B' for r in records],dtype=float)
    event('FIRST_CORE_CLINICAL_MODEL_FIT_STARTED',protocol_sha256=FREEZE_HASH,independent_source_gate_sha256=sha(LINK),script_sha256=sha(Path(__file__)),note='First fit by this core implementation; separately authorized independent implementation may have started after the same actual freeze')
    primary=[];within=[];group_specific=[];B_sensitivity=[];loo_summary=[];loo_local=[];failures=[]
    for name in ['IFNA','OXPHOS']:
        z=scores['A'][name]['z']
        mainfit=fit_hc3(y,z);mainfit.update(exposure=name,variant='A',model='LVEF~zScore',role='PRIMARY_EXPLORATORY_SELECTED_SPECTRUM',score_SD=scores['A'][name]['SD'],score_mean=scores['A'][name]['mean']);primary.append(mainfit)
        w=fit_hc3(y,z,group);w.update(exposure=name,variant='A',model='LVEF~zScore+C(original_group)',role='WITHIN_SELECTION_GROUP_DESCRIPTIVE',score_scale='same full32-patient A zScore',group_adjustment_is_not_bias_or_confounding_repair=True);within.append(w)
        for label in ['A','B']:
            mask=np.asarray([r['group']==label for r in records]);g=fit_hc3(y[mask],z[mask]);g.update(exposure=name,variant='A',original_group=label,model='LVEF~zScore within original group',role='PREDECLARED_GROUP_SPECIFIC_DESCRIPTIVE',score_scale='same full32-patient A zScore',BH_family=None);group_specific.append(g)
        bfit=fit_hc3(y,scores['B'][name]['z']);bfit.update(exposure=name,variant='B',model='LVEF~zScore',role='WHOLE_SCORING_SCHEME_SENSITIVITY',score_SD=scores['B'][name]['SD'],score_mean=scores['B'][name]['mean'],A_B_difference_not_pure_imputation_effect=True,HC3_conditional_on_imputed_working_score=True,imputation_uncertainty_not_covered=True);B_sensitivity.append(bfit)
        local=[]
        for i in range(32):
            keep=np.arange(32)!=i;fit=fit_hc3(y[keep],z[keep]);local.append(fit)
            row={'exposure':name,'omitted_GSM':records[i]['gsm'],'status':fit['status'],'n':31,'original_full32_score_scale_retained':True}
            for key in ['beta_LVEF_percentage_points_per_selected_sample_SD','HC3_SE','CI95_low','CI95_high','P_two_sided_t_HC3','residual_df']:row[key]=fit.get(key)
            loo_local.append(row)
        estimated=[x for x in local if x['status']=='ESTIMATED'];betas=[x['beta_LVEF_percentage_points_per_selected_sample_SD'] for x in estimated]
        fullbeta=mainfit.get('beta_LVEF_percentage_points_per_selected_sample_SD')
        loo_summary.append({'exposure':name,'variant':'A','attempted_fits_n':32,'successful_fits_n':len(estimated),'failed_fits_n':32-len(estimated),'beta_range':[min(betas),max(betas)] if betas else None,'positive_beta_n':sum(v>0 for v in betas),'negative_beta_n':sum(v<0 for v in betas),'max_absolute_beta_change_from_full':max(abs(v-fullbeta) for v in betas) if fullbeta is not None and betas else None,'scale':'Fixed original32-patient score mean/SD; no patient deletion from primary analysis'})
        for model in [mainfit,w,bfit,*[x for x in group_specific if x['exposure']==name],*local]:
            if model['status']!='ESTIMATED':failures.append({'exposure':name,**model})
    for fit,q in zip(primary,bh_two(primary)):fit['BH_q_two_primary_tests_only']=q
    with (LOCAL/'LEAVE_ONE_PATIENT_OUT_LOCAL_ONLY.csv').open('w',encoding='utf-8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(loo_local[0]));writer.writeheader();writer.writerows(loo_local)
    expected_model_counts={'primary':2,'within_original_group':2,'group_specific_descriptive':4,'B_sensitivity':2,'LOO':64}
    assert all(x['n']==32 and x.get('residual_df')==30 for x in primary+B_sensitivity if x['status']=='ESTIMATED')
    assert all(x['n']==32 and x.get('residual_df')==29 for x in within if x['status']=='ESTIMATED')
    assert all(x['n']==16 and x.get('residual_df')==14 for x in group_specific if x['status']=='ESTIMATED')
    assert all(x['n']==31 and x.get('residual_df')==29 for x in loo_local if x['status']=='ESTIMATED')
    assert inputs_before==[identity(path) for path in all_input_paths]
    results={'status':'ALL_PREDECLARED_NUMERICAL_TASKS_COMPLETE' if not failures else 'NUMERICAL_TASKS_COMPLETE_WITH_REPORTED_FAILURES','generated_at_utc':stamp(),'actual_model':'gpt-6.1-sol','reasoning_effort':'high','frozen_protocol':identity(FROZEN),'source_admission':identity(ADMISSION),'independent_source_gate':identity(LINK),'implementation':identity(Path(__file__)),'libraries':{'numpy':np.__version__,'scipy':scipy.__version__},'inputs_unchanged':True,'patient_n':32,'selected_original_groups':{'A_low_EF':16,'B_high_EF':16},'outcome':'Same-patient one-month post-MI Simpson echocardiographic LVEF, percent','effect_unit':'LVEF percentage points per selected-sample1SD of the specified relative-reference gene-subset rank score','primary':primary,'within_original_selection_group':within,'group_specific_descriptive':group_specific,'B_whole_scoring_scheme_sensitivity':B_sensitivity,'leave_one_patient_out_summary':loo_summary,'all_model_failures':failures,'expected_model_counts':expected_model_counts,'actual_total_fits':74,'primary_multiplicity':'BH over exactly2 primary exploratory tests only; sensitivities remain prespecified descriptive checks, no preferred-result substitution','selection_boundary':'Two extremes of outcome-defined selection; unadjusted selected-spectrum association only. No baseline-adjusted recovery, general AMI slope, causal mechanism or incremental prediction','B_boundary':'Joint background, target membership and missing-value handling changes; HC3 conditions on imputed working score and does not quantify imputation uncertainty','influence_boundary':'All32 retained in primary; LOO diagnostics do not authorize deletion','no_new_gene_selection_or_threshold_optimization':True,'LOCAL_ONLY_files':[identity(x) for x in LOCAL.iterdir() if x.is_file()],'individual_rows_in_this_aggregate_file':False,'new_network_requests_by_core':0,'MIMIC_eICU_access':0,'manuscript_body_or_actual_figures_created':0,'actual_new_scores':{'A_IFNA':32,'A_OXPHOS':32,'B_IFNA':32,'B_OXPHOS':32},'actual_new_clinical_models':expected_model_counts,'independent_numeric_reproduction_status':'PENDING_SEPARATE_IMPLEMENTATION_COMPARISON'}
    write(OUT/'CLINICAL_RESULTS_AGGREGATE.json',results)
    summary_rows=[]
    for family,models in [('primary',primary),('within_original_group',within),('group_specific',group_specific),('B_sensitivity',B_sensitivity)]:
        for model in models:summary_rows.append({'family':family,'exposure':model['exposure'],'variant':model['variant'],'original_group':model.get('original_group','all'),'status':model['status'],'n':model['n'],'df':model.get('residual_df'),'beta_pp_per_SD':model.get('beta_LVEF_percentage_points_per_selected_sample_SD'),'HC3_SE':model.get('HC3_SE'),'CI95_low':model.get('CI95_low'),'CI95_high':model.get('CI95_high'),'P_raw':model.get('P_two_sided_t_HC3'),'BH_q_primary2_only':model.get('BH_q_two_primary_tests_only')})
    with (OUT/'CLINICAL_MODEL_SUMMARY_AGGREGATE.csv').open('w',encoding='utf-8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(summary_rows[0]));writer.writeheader();writer.writerows(summary_rows)
    event('ALL_PREDECLARED_CORE_MODELS_FINISHED',protocol_sha256=FREEZE_HASH,results=identity(OUT/'CLINICAL_RESULTS_AGGREGATE.json'),actual_total_fits=74,failed_model_count=len(failures),primary_family_size=2)
    events=[json.loads(x) for x in (OUT/'CLINICAL_EXECUTION_EVENTS.jsonl').read_text(encoding='utf-8').splitlines()]
    first_fit=next(x for x in events if x['event']=='FIRST_CORE_CLINICAL_MODEL_FIT_STARTED')
    assert datetime.fromisoformat(frozen['frozen_at_utc'])<datetime.fromisoformat(first_fit['time_utc'])
    write(OUT/'FREEZE_BEFORE_FIT_VERIFICATION.json',{'status':'PASS','actual_frozen_at_utc':frozen['frozen_at_utc'],'first_core_model_fit_at_utc':first_fit['time_utc'],'frozen_protocol_sha256':FREEZE_HASH,'independent_source_gate_was_PASS_before_freeze':True,'conditional_protocol_original_unchanged':sha(CONDITIONAL)==CONDITIONAL_HASH,'clinical_execution_events':identity(OUT/'CLINICAL_EXECUTION_EVENTS.jsonl'),'no_backdating_or_inferred_freeze':True})
    write(OUT/'NUMERICAL_OUTPUT_MANIFEST.json',{'generated_at_utc':stamp(),'protocol_frozen_before_core_effect':True,'frozen_protocol':identity(FROZEN),'aggregate_outputs':[identity(OUT/name) for name in ['SOURCE_CLINICAL_ADMISSION.json','SCORE_DEFINITION_AND_MEMBER_HASHES.json','SCORE_DIAGNOSTICS_AGGREGATE.json','CLINICAL_RESULTS_AGGREGATE.json','CLINICAL_MODEL_SUMMARY_AGGREGATE.csv','FREEZE_BEFORE_FIT_VERIFICATION.json']],'scripts':[identity(OUT/name) for name in ['prepare_clinical_admission_and_freeze.py','run_frozen_clinical_analysis.py']],'LOCAL_ONLY_not_for_model_preview_or_external_delivery':True})
    print(json.dumps({'status':results['status'],'patients':32,'total_predeclared_fits':74,'failures':len(failures),'primary':[{'exposure':x['exposure'],'beta_pp_per_SD':x.get('beta_LVEF_percentage_points_per_selected_sample_SD'),'CI95':[x.get('CI95_low'),x.get('CI95_high')],'P':x.get('P_two_sided_t_HC3'),'BH_q':x.get('BH_q_two_primary_tests_only')} for x in primary],'within_group':[{'exposure':x['exposure'],'beta_pp_per_SD':x.get('beta_LVEF_percentage_points_per_selected_sample_SD'),'CI95':[x.get('CI95_low'),x.get('CI95_high')]} for x in within],'results':str(OUT/'CLINICAL_RESULTS_AGGREGATE.json'),'result_sha256':sha(OUT/'CLINICAL_RESULTS_AGGREGATE.json')},ensure_ascii=False))

if __name__=='__main__':
    try:main()
    except Exception as error:
        failure={'time_utc':stamp(),'status':'CORE_IMPLEMENTATION_EXCEPTION_PRESERVED','error_type':type(error).__name__,'error_message':str(error),'traceback':traceback.format_exc(),'patient_rows_exported':False,'script':identity(Path(__file__))}
        write(OUT/f'CORE_FAILURE_{datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")}.json',failure)
        raise

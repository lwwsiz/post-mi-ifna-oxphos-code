"""Local source admission and actual pre-effect protocol freeze; no scores/effects."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import copy, hashlib, json, os, re, statistics, xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
BASE = OUT.parents[1]
FULL = BASE / 'candidate_sources/GSE11947_family_all_official_full.source'
BRIEF = BASE / 'candidate_sources/GSE11947_GSM_brief.soft'
SOURCES = BASE / 'sources/original_methods_extension_20261005'
CONDITIONAL = BASE / 'protocol/scoring_preflight/CONDITIONAL_ANALYSIS_PROTOCOL_UNFROZEN.json'
FROZEN = BASE / 'protocol/CLINICAL_ANALYSIS_FROZEN_20261005.json'
LINK = BASE / 'analysis/clinical_independent_20261005/SOURCE_GATE_INDEPENDENT.json'
CLOSURE = BASE / 'review/Astra_GSE11947_DESIGN_CLOSURE.json'
AUTH = BASE / 'resume_authorization_20261005.json'
EXPECTED_CONDITIONAL = 'a9e0c72ae587352f96ce13607418d914b8799c9024be581acefe636092cb7d3b'

def stamp(): return datetime.now(timezone.utc).isoformat()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def identity(path): return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}
def write(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def event(name,**fields):
    with (OUT/'CLINICAL_EXECUTION_EVENTS.jsonl').open('a',encoding='utf-8') as handle:
        handle.write(json.dumps({'time_utc':stamp(),'event':name,**fields},ensure_ascii=False)+'\n');handle.flush();os.fsync(handle.fileno())

def sample_metadata(path):
    records=[];current=None
    with path.open(encoding='utf-8') as handle:
        for raw in handle:
            line=raw.rstrip('\r\n')
            if line.startswith('^SAMPLE = '):
                current={'gsm':line.split(' = ',1)[1],'fields':{}};records.append(current)
            elif current is not None and line.startswith('!Sample_') and ' = ' in line:
                key,value=line.split(' = ',1);current['fields'].setdefault(key,[]).append(value)
    output={}
    for record in records:
        f=record['fields'];ref=[ch for ch in (1,2) if f[f'!Sample_source_name_ch{ch}'][0].strip().casefold()=='ref']
        assert len(ref)==1;test=3-ref[0]
        chars={k.strip():v.strip() for raw in f[f'!Sample_characteristics_ch{test}'] if ':' in raw for k,v in [raw.split(':',1)]}
        assert chars['Subject_reference']==chars['Sample_reference']
        values=[float(m[1]) for x in f['!Sample_description'] if (m:=re.fullmatch(r'ejection fraction \(EF\):\s*(\d+(?:\.\d+)?)',x,re.I))]
        groups=[m[1].strip() for x in f['!Sample_description'] if (m:=re.fullmatch(r'group:\s*(.*)',x))]
        assert len(values)==len(groups)==1
        assert record['gsm'] not in output
        output[record['gsm']]={'subject':chars['Subject_reference'],'sample':chars['Sample_reference'],'ef':values[0],'group':groups[0]}
    assert len(output)==32 and len({x['subject'] for x in output.values()})==32
    return output

def main():
    assert sha(CONDITIONAL)==EXPECTED_CONDITIONAL
    assert not FROZEN.exists(), 'Preserve actual existing freeze; do not refreeze on rerun'
    auth=json.loads(AUTH.read_text(encoding='utf-8'));assert auth['user_latest_instruction']=='计算新的临床关联'
    link=json.loads(LINK.read_text(encoding='utf-8'));assert link['status'].startswith('PASS_') and len(link['checks'])==17 and all(link['checks'].values())
    closure=json.loads(CLOSURE.read_text(encoding='utf-8'));assert closure['final_protocol_sha256']==EXPECTED_CONDITIONAL and closure['remaining_must_fix_count']==0
    clinical=sample_metadata(FULL);assert clinical==sample_metadata(BRIEF)
    cross=Counter((r['group'],'EF<=40' if r['ef']<=40 else 'EF>40') for r in clinical.values())
    assert cross=={('A','EF<=40'):16,('B','EF>40'):16}
    summaries={}
    for group in ['A','B']:
        values=[r['ef'] for r in clinical.values() if r['group']==group]
        summaries[group]={'patients':len(values),'mean':statistics.mean(values),'sample_SD':statistics.stdev(values),'median':statistics.median(values),'range':[min(values),max(values)]}
    assert summaries['A']['median']==35 and summaries['A']['range']==[20,40]
    assert summaries['B']['median']==63 and summaries['B']['range']==[45,73]
    assert round(summaries['A']['mean'])==33 and round(summaries['A']['sample_SD'])==7
    assert round(summaries['B']['mean'])==61 and round(summaries['B']['sample_SD'])==10
    publications=[]
    for filename,expected in [('PMC2836383_fullText.xml','c8a6593a5f11b192f72298d9f0601ea8f113fb7a1537dc83a03aa60ca840e87b'),('PMC2890499_fullText.xml','4058a06d6d8054e9a7128db3240dbb6812bc9a05398ecadd377b42f481ab2c3f')]:
        path=SOURCES/filename;assert sha(path)==expected;root=ET.fromstring(path.read_bytes())
        ids={x.get('pub-id-type'):x.text for x in root.findall('.//article-id')}
        sec='s2e' if filename.startswith('PMC283') else 'sec10'
        texts=[' '.join(' '.join(x.itertext()).split()) for x in root.findall(f'.//sec[@id="{sec}"]/p')]
        joined=' '.join(texts)
        assert 'mechanical reperfusion' in joined and '1 month after MI' in joined and 'PAXgene' in joined
        if sec=='s2e':assert "Simpson's method" in joined and 'GSE11947' in joined and '32 MI patients' in joined and '≤40%' in joined
        else:assert '16 patients' in joined and 'median 63%' in joined and 'median 35%' in joined
        assert f'!Series_pubmed_id = {ids["pmid"]}' in FULL.read_text(encoding='utf-8')
        publications.append({'source':identity(path),'article_ids':ids,'section_id':sec,'method_paragraphs':texts})
    admission={
        'status':'PASS_SAME_PATIENT_MECHANICAL_REPERFUSION_BLOOD_TO_ONE_MONTH_LVEF_SELECTED_SPECTRUM',
        'created_at_utc':stamp(),'actual_model':'gpt-6.1-sol','reasoning_effort':'high',
        'inputs':[identity(x) for x in [FULL,BRIEF,SOURCES/'PubMed_3PMIDs.xml',AUTH]],
        'primary_method_evidence':publications,'independent_source_gate':identity(LINK),'independent_source_checks_passed':17,
        'sample_patient_link':{'GSM_n':32,'unique_original_Subject_reference_n':32,'Subject_equals_Sample_reference_n':32,'full_vs_brief_metadata_identical':True,'patient_key_rule':'Use submitted nonreference-channel Subject_reference as written; no title-inferred key or cross-cohort join'},
        'original_group_x_40_threshold':[{'original_group':g,'threshold_category':k,'patients':count} for (g,k),count in sorted(cross.items())],
        'GEO_group_EF_aggregate':summaries,
        'source_consistency':{'PMC2890499_medians_and_ranges_match_individual_GEO_aggregate':True,'PMC2836383_rounded_group_means_SDs_match_GEO_aggregate':True,'timing_method_unit_conflicts_n':0},
        'exposure_collection':'PAXgene whole blood at mechanical reperfusion for acute MI',
        'outcome':'Echocardiographic LVEF by Simpson method1 month after MI, original percent; slope unit percentage points',
        'selection':'Official series says extreme EF quartiles; papers dichotomize same one-month EF at40%. Retain selected two-end population, not all AMI patients',
        'missing_covariates':['baseline EF','individual age','individual sex'],
        'limitations':['No baseline EF change/recovery estimand','Age/sex matching described in publication does not create individual covariate fields or matched-pair IDs','Gene-specific universal-reference ratio rank subsets are a distinct measurement layer from PBMC'],
        'single_patient_rows_exported':False,'new_network_requests':0,'clinical_effects_at_admission':0,
        'script':identity(Path(__file__)),
    }
    write(OUT/'SOURCE_CLINICAL_ADMISSION.json',admission)
    event('SOURCE_CLINICAL_ADMISSION_PASS',admission=identity(OUT/'SOURCE_CLINICAL_ADMISSION.json'),independent_source_gate=identity(LINK),scores_computed=0,clinical_effects_computed=0)
    frozen=copy.deepcopy(json.loads(CONDITIONAL.read_text(encoding='utf-8')))
    frozen.update(status='FROZEN_SELECTED_SPECTRUM_ONE_MONTH_LVEF_ANALYSIS_20261005',frozen=True,frozen_at_utc=stamp(),clinical_effects_previously_computed=False,pathway_scores_previously_computed=False)
    frozen['freeze_provenance']={'user_authorization':identity(AUTH),'conditional_protocol_original':identity(CONDITIONAL),'actual_Astra_design_closure':identity(CLOSURE),'source_admission':identity(OUT/'SOURCE_CLINICAL_ADMISSION.json'),'independent_source_gate':identity(LINK),'method_specification_changed_after_review':False,'source_facts_newly_verified':True,'clinical_pre_effect_plan_not_preregistered_or_blind':True}
    frozen['former_blocked_requirements_preserved']=frozen['blocked_requirements_before_freeze_or_effect'];frozen['blocked_requirements_before_freeze_or_effect']=[]
    frozen['historical_design_revision_fields_note']='Original revision/source-HOLD metadata is retained as historical provenance. Active20261005 clinical admission and executable freeze supersede the former factual source HOLD for this exact study/outcome only'
    frozen['conditional_primary_scoring_recommendation']['status']='FROZEN_PRIMARY_A_NO_IMPUTATION'
    frozen['conditional_primary_scoring_recommendation']['source_gate']='PASS_SAME_PATIENT_ONE_MONTH_EF'
    frozen['conditional_primary_analysis']['exposure_timing']='Whole-blood PAXgene sampling at mechanical reperfusion during index acute MI'
    frozen['conditional_primary_analysis']['outcome']='Same-patient LVEF measured1 month after MI by echocardiography using Simpson method, original unit percent; report LVEF percentage points'
    frozen['conditional_primary_analysis']['estimand']='Unadjusted descriptive linear projection of one-month LVEF percentage points on each separate relative-reference A score per1 selected-sampleSD among32 patients selected at EF extremes. Not population-wide AMI effect, recovery change or independent clinical prediction'
    frozen['active_source_factual_gate']='PASS_WITH_SELECTED_SPECTRUM_LIMITS'
    frozen['implementation_choices_before_effect']={'group_indicator':'Original GEO group B indicator versus group A baseline; never reconstructed from model effects','LOO_score_scale':'Keep original32-patient score mean/SD fixed for leave-one-patient-out influence models','group_specific_descriptive_scale':'Keep full selected-sample z scale for each original-group descriptive model; no new multiplicity family','model_failure':'Archive rank/nonfinite/zero-variation/undefined-HC3 failures, no effect-based method replacement','B_role':'Two separate ungrouped whole-scoring-scheme sensitivity fits; no main-result substitution, no additional C scoring'}
    write(FROZEN,frozen)
    event('PROTOCOL_ACTUALLY_FROZEN_BEFORE_SCORES_OR_EFFECTS',protocol=identity(FROZEN),conditional_protocol_original_sha256=EXPECTED_CONDITIONAL,independent_source_gate=identity(LINK),scores_computed=0,clinical_effects_computed=0)
    assert sha(CONDITIONAL)==EXPECTED_CONDITIONAL
    print(json.dumps({'source_gate':admission['status'],'patients_n':32,'cross_table':[{'group':g,'category':k,'n':v} for (g,k),v in sorted(cross.items())],'frozen_protocol':str(FROZEN),'frozen_sha256':sha(FROZEN),'frozen_at_utc':frozen['frozen_at_utc'],'scores':0,'clinical_effects':0},ensure_ascii=False))

if __name__=='__main__':main()

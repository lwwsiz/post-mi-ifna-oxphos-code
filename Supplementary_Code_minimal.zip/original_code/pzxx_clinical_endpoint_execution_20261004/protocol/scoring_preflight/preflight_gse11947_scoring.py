"""Local scoring preflight without using EF association results.

EF values and extreme selection are already known; this is not blind validation.
No pathway scores or clinical effects are calculated.

Uses the official family source and previously frozen HGNC/Hallmark inputs.
Patient expression is used in memory solely for finite-value coverage. Neither
patient identifiers, expression rows nor EF values are exported by this script.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import statistics
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
EXEC = OUT.parents[1]
OLD = EXEC.parent / "pzxx_execution_20261004"
SOURCE = EXEC / "candidate_sources/GSE11947_family_all_official_full.source"
HGNC = OLD / "inputs/hgnc_complete_set_20261004.txt"
SETS = OLD / "GENE_SETS_FROZEN.json"
OLD_PROTOCOL = OLD / "PROTOCOL_FROZEN.json"
ROUND2_SETS = EXEC.parent / "pzxx_local_first_execution_20261004/protocol/ROUND2_GENE_SETS_AND_UNIVERSES_FROZEN.json"
HALLMARK = {"IFNA": OLD / "inputs/Hallmark_IFNA.json", "OXPHOS": OLD / "inputs/Hallmark_OXPHOS.json"}


def fingerprint(path: Path) -> dict:
    content = path.read_bytes()
    return {"path": str(path), "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}


def membership_hash(members: set[str]) -> str:
    return hashlib.sha256(("\n".join(sorted(members)) + "\n").encode("utf-8")).hexdigest()


def finite(value: float | None) -> bool:
    return value is not None and math.isfinite(value)


def load_hgnc() -> tuple[set[str], dict[str, set[str]]]:
    approved = set()
    aliases = defaultdict(set)
    with HGNC.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            if row["status"] != "Approved":
                continue
            symbol = row["symbol"]
            approved.add(symbol)
            for field in ("alias_symbol", "prev_symbol"):
                for token in row[field].split("|"):
                    if token:
                        aliases[token].add(symbol)
    return approved, aliases


def resolve(token: str, approved: set[str], aliases: dict[str, set[str]]) -> tuple[str | None, str]:
    if token in approved:
        return token, "approved_symbol"
    targets = aliases.get(token, set())
    if len(targets) == 1:
        return next(iter(targets)), "unique_alias_or_previous_symbol"
    return None, "ambiguous_alias" if len(targets) > 1 else "unresolved_token"


def map_annotation(value: str, approved: set[str], aliases: dict[str, set[str]]) -> tuple[str | None, str]:
    # A supported token plus an unresolved token is excluded, rather than
    # silently dropping the unresolved part of a multi-symbol annotation.
    tokens = [x.strip() for x in re.split(r";|///|//|\||,", value) if x.strip()]
    if not tokens:
        return None, "empty_annotation"
    targets, statuses = [], []
    for token in tokens:
        target, status = resolve(token, approved, aliases)
        targets.append(target)
        statuses.append(status)
    if "ambiguous_alias" in statuses:
        return None, "ambiguous_alias_annotation_excluded"
    if None in targets:
        return None, "partly_or_fully_unresolved_annotation_excluded"
    unique = set(targets)
    if len(unique) != 1:
        return None, "multiple_distinct_approved_genes_excluded"
    return next(iter(unique)), "all_tokens_resolve_one_approved_gene"


def read_family() -> tuple[dict[str, str], list[dict[str, float | None]], Counter]:
    platform, samples, definitions = {}, [], Counter()
    table = None
    header = None
    current = None
    with SOURCE.open(encoding="utf-8") as handle:
        for raw in handle:
            line = raw.rstrip("\r\n")
            if line.startswith("#VALUE = "):
                definitions[line.split(" = ", 1)[1]] += 1
            if line == "!platform_table_begin":
                table, header = "platform", None
                continue
            if line == "!sample_table_begin":
                table, header, current = "sample", None, {}
                continue
            if line == "!platform_table_end":
                table = None
                continue
            if line == "!sample_table_end":
                samples.append(current)
                table = None
                continue
            if table is None:
                continue  # Clinical metadata, including EF, is never parsed.
            if header is None:
                header = line.split("\t")
                continue
            fields = line.split("\t")
            assert len(fields) == len(header)
            row = dict(zip(header, fields))
            if table == "platform":
                assert row["ID"] not in platform
                platform[row["ID"]] = row["GENE_SYMBOL"].strip()
            else:
                assert row["ID_REF"] not in current
                try:
                    number = float(row["VALUE"])
                    current[row["ID_REF"]] = number if math.isfinite(number) else None
                except ValueError:
                    assert row["VALUE"].strip().casefold() in ("", "na", "nan", "null")
                    current[row["ID_REF"]] = None
    assert table is None and len(platform) == 26880 and len(samples) == 32
    assert definitions == {"Lowess-normalized, log2 (test/ref) ratio": 32}
    assert all(set(row) == set(samples[0]) for row in samples)
    return platform, samples, definitions


def set_coverage(members: set[str], universe: set[str], expression: dict[str, list[float | None]], n: int) -> dict:
    measured = members & universe
    observed = [sum(finite(expression[g][i]) for g in measured) for i in range(n)]
    return {
        "fixed_input_target_genes_n": len(members), "mapped_universe_members_n": len(measured),
        "coverage_of_fixed_input_target": len(measured) / len(members),
        "universe_members_sha256_sorted_newline": membership_hash(measured),
        "per_sample_observed_member_count_histogram": dict(Counter(observed)),
        "per_sample_missing_member_count_histogram": dict(Counter(len(measured) - x for x in observed)),
        "patients_complete_for_this_candidate_set_n": sum(x == len(measured) for x in observed),
        "missing_entries_over_all_samples_n": n * len(measured) - sum(observed),
    }


def main() -> None:
    paths = [SOURCE, HGNC, SETS, OLD_PROTOCOL, ROUND2_SETS, *HALLMARK.values()]
    fingerprints_before = [fingerprint(path) for path in paths]
    old_protocol = json.loads(OLD_PROTOCOL.read_text(encoding="utf-8"))
    frozen_sets = json.loads(SETS.read_text(encoding="utf-8"))
    for path in [HGNC, *HALLMARK.values()]:
        assert fingerprint(path)["sha256"] == old_protocol["set_version_and_hash"][path.name]
    approved, aliases = load_hgnc()
    members = {}
    for name, path in HALLMARK.items():
        obj = json.loads(path.read_text(encoding="utf-8"))
        original = next(iter(obj.values()))["geneSymbols"]
        targets = [resolve(x, approved, aliases)[0] for x in original]
        assert None not in targets
        members[name] = set(targets)
        assert members[name] == set(frozen_sets[name]["declared_genes"])
    assert len(members["IFNA"]) == 97 and len(members["OXPHOS"]) == 200
    declared_members = members
    round2 = json.loads(ROUND2_SETS.read_text(encoding="utf-8"))
    round2_members = {name: set(round2["bulk_primary_sets"][name]) for name in ("IFNA", "OXPHOS")}
    assert all(round2_members[name] == set(frozen_sets[name]["measured_genes"]) for name in round2_members)
    assert len(round2_members["IFNA"]) == 95 and len(round2_members["OXPHOS"]) == 197
    platform, samples, definitions = read_family()
    probes = set(samples[0])
    assert probes <= set(platform)
    mapping_status = Counter()
    gene_probes = defaultdict(list)
    for probe in sorted(probes):
        gene, status = map_annotation(platform[probe], approved, aliases)
        mapping_status[status] += 1
        if gene is not None:
            gene_probes[gene].append(probe)
    expression = {}
    for gene, gene_probe_ids in gene_probes.items():
        values = []
        for sample in samples:
            finite_probes = [sample[p] for p in gene_probe_ids if finite(sample[p])]
            values.append(statistics.median(finite_probes) if finite_probes else None)
        expression[gene] = values
    n = len(samples)
    observed_count = {g: sum(finite(x) for x in row) for g, row in expression.items()}
    mapped_universe = set(expression)
    universes = {
        "all_mapped": mapped_universe,
        "at_least_one_observed": {g for g, count in observed_count.items() if count >= 1},
        "all_32_observed": {g for g, count in observed_count.items() if count == n},
        "at_least_31_observed": {g for g, count in observed_count.items() if count >= 31},
        "at_least_29_observed": {g for g, count in observed_count.items() if count >= 29},
        "at_least_26_observed": {g for g, count in observed_count.items() if count >= 26},
    }
    candidates = {}
    for label, universe in universes.items():
        row_missing = [sum(not finite(expression[g][i]) for g in universe) for i in range(n)]
        candidate_sets = {name: set_coverage(genes, universe, expression, n) for name, genes in members.items()}
        target_union = (members["IFNA"] | members["OXPHOS"]) & universe
        candidates[label] = {
            "universe_genes_n": len(universe),
            "universe_sha256_sorted_newline": membership_hash(universe),
            "universe_gene_sample_missing_entries_n": sum(row_missing),
            "per_sample_background_missing_gene_count_histogram": dict(Counter(row_missing)),
            "patients_complete_background_n": sum(x == 0 for x in row_missing),
            "patients_complete_both_target_sets_n": sum(all(finite(expression[g][i]) for g in target_union) for i in range(n)),
            "target_sets": candidate_sets,
            "PBMC_round2_measured_subset_identity_only_coverage": {name: set_coverage(genes, universe, expression, n) for name, genes in round2_members.items()},
            "target_overlap_n": len(members["IFNA"] & members["OXPHOS"] & universe),
        }
    summary = {
        "status": "LOCAL_SCORING_PREFLIGHT_NO_EF_ASSOCIATION_COMPLETE_CLINICAL_HOLD",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "inputs": fingerprints_before, "script": fingerprint(Path(__file__)),
        "input_frozen_hash_checks": "PASS HGNC and both original Hallmark files match original frozen protocol; full declared canonical sets equal original frozen declared_genes; ROUND2 fixed targets95/197 exactly equal original measured_genes",
        "target_list_identity": "Conditional primary targets are original frozen Hallmark declared IFNA97/OXPHOS200 intersected with the new study's fixed measurable background. ROUND2 IFNA95/OXPHOS197 are the original PBMC measured subsets and are compared only for source identity; they do not determine this independent study's target membership",
        "not_blind_validation": "32 EF values and extreme-selection metadata were already inspected; preflight uses expression coverage without any new EF association result. No claim of blinded validation or preregistration",
        "patients_expression_objects_n": n,
        "clinical_EF_metadata_parsed": False,
        "exported_scale": dict(definitions),
        "HGNC_approved_symbols_n": len(approved),
        "mapping_rule": "Case-sensitive approved-symbol precedence, else a unique HGNC previous/alias target. Semicolon/explicit multi-token annotations require every token to resolve to the same one approved gene; unknown or multi-target annotations excluded. No case conversion, description guessing or Entrez rescue",
        "expression_probes_n": len(probes), "mapping_probe_status_counts": dict(mapping_status),
        "unique_mapped_genes_n": len(gene_probes),
        "probe_multiplicity_per_gene_histogram": dict(Counter(len(x) for x in gene_probes.values())),
        "duplicate_probe_aggregation": "Per patient median over finite log2(test/ref) values of all unambiguously mapped probes for the same approved gene; all probes missing gives gene missing; no probe selection by EF or variance; no missing-to-zero fill",
        "gene_observed_patient_count_histogram": dict(Counter(observed_count.values())),
        "universe_candidates": candidates,
        "guardrails": {"new_source_requests": 0, "pathway_scores_calculated": 0, "clinical_associations_calculated": 0, "individual_rows_exported": 0, "original_inputs_modified": False, "PBMC_individual_data_merged": False},
    }
    assert fingerprints_before == [fingerprint(path) for path in paths]
    (OUT / "SCORING_PREFLIGHT_AGGREGATE.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    strict = candidates["all_32_observed"]
    liberal = candidates["at_least_29_observed"]
    protocol = {
        "status": "UNFROZEN_CONDITIONAL_DRAFT_NO_SCORES_NO_CLINICAL_EFFECTS",
        "plan_id": "PZXX-LVEF-BRIDGE-PROPOSAL-1",
        "study": "GSE11947 selected extreme-EF-quartile whole-blood cohort",
        "model_role": "gpt-6.1-sol high local deterministic preflight and conditional design",
        "source_fingerprints": fingerprints_before,
        "preflight_summary": fingerprint(OUT / "SCORING_PREFLIGHT_AGGREGATE.json"),
        "authorization_boundary": "Existing steps1-7 authorization; local preparation only; global24/24 source cap exhausted, proposed additional6 requests not authorized in this subtask",
        "blocked_requirements_before_freeze_or_effect": [
            "Original matching paper/clinical methods confirm blood collection time and EF measurement time/order, original EF unit and method",
            "Sampling timing qualifies as early acute-phase exposure preceding explicitly defined follow-up EF; absent follow-up timing cannot be relabelled recovery",
            "Choose one fixed background/missingness recipe using only expression coverage and documented design, before any new EF association; record it as frozen",
            "Concretely unresolved selection/missingness estimand issues receive only the narrow design review decided by root; no implied Astra call",
        ],
        "independent_unit": "32 submitted independent patients per official series; four technical slides each already represented by one processed patient object; no technical replication as patient n",
        "mapping": summary["mapping_rule"],
        "gene_aggregation": summary["duplicate_probe_aggregation"],
        "scoring_candidates": [
            {
                "id": "A_complete_common_background",
                "recommendation": "Most conservative common-background option; assess content coverage before choosing. Missingness-defined gene restriction is frozen from expression only and retained in the interpretation",
                "recipe": "U32 = mapped genes with finite aggregated log2(test/ref) in all32 subjects. Both scores rank against exactly U32; each target is original frozen Hallmark declared IFNA97/OXPHOS200 intersect U32. No imputation, no sample deletion",
                "background_genes_n": strict["universe_genes_n"], "background_membership_sha256": strict["universe_sha256_sorted_newline"],
                "target_coverage": strict["target_sets"],
                "cost": "Drops any gene missing in even one patient; may substantially change represented IFNA/OXPHOS content. It estimates ranks for the measured subset, not the entire Hallmark program; coverage shortfall may keep score gate HOLD rather than silently change method",
            },
            {
                "id": "B_at_least29_common_background_gene_median_imputation",
                "recommendation": "Alternative only if content coverage loss in A is material and the imputation estimand is accepted before effects; suitable fixed sensitivity if A is primary, never pick by significance",
                "recipe": "U29 = mapped genes finite in at least29/32 patients. For each gene fill missing entries with median of that gene's observed values within this same GSE11947 cohort. Both scores rank on exactly fixed U29. Never impute0 or use EF/EF group in imputation",
                "background_genes_n": liberal["universe_genes_n"], "background_membership_sha256": liberal["universe_sha256_sorted_newline"],
                "target_coverage": liberal["target_sets"],
                "missing_background_entries_to_fill_n": liberal["universe_gene_sample_missing_entries_n"],
                "cost": "Retains more target genes but substitutes unobserved reference ratios; creates ties/shrinks variation, and can bias association if missingness depends on clinical or technical factors. This is a deterministic working assumption, not proof of MAR. Do not claim crossvalidated prediction",
            },
            {
                "id": "C_available_case_variable_ranking_background",
                "recommendation": "Not recommended as primary; only a prespecified scoring sensitivity if specifically accepted",
                "recipe": "Within fixed U29 take each patient's observed genes and target members only; N and m vary per patient; recompute normalization for those actually observed",
                "cost": "No imputation but patient scores reflect different backgrounds/target membership, potentially confounding program level with missingness. Coverage thresholds must be fixed without EF; cannot compare this score numerically to A/B or PBMC",
            },
        ],
        "score_definition_if_chosen": {
            "direction": "Up-directed IFNA/OXPHOS single-sample ranks of exported log2(patient/reference) ratio; no second log transform, no cohort centering per gene or new quantile normalization",
            "formula": "Average-tie increasing ranks; score=(mean_rank_of_m_target_genes-(m+1)/2)/(N-m)-0.5, with fixed background N and fixed measured target m for A/B",
            "scope": "Same scoring algebra as existing frozen rank method, but this study's relative-to-Universal-Reference expression scale and measured background are separate. No PBMC merging or numeric score calibration",
            "nondegenerate_gate": "N>m>0; all chosen matrix entries finite after accepted handling; each exposure sampleSD>0; actual fixed-gene coverage reported and content limitations accepted before model fitting",
            "fixed_target_set_sources": [fingerprint(SETS), *[fingerprint(path) for path in HALLMARK.values()]],
            "fixed_target_set_sizes": {name: len(genes) for name, genes in members.items()},
            "full_Hallmark_declared_reference_sizes": {name: len(genes) for name, genes in declared_members.items()},
            "target_list_boundary": "Original declared97/200 define target membership before new-study observability restrictions. ROUND2 measured95/197 belong to PBMC; no automatic exclusion of5 genes merely absent from that old platform and no imported PBMC18850 ranking background",
            "no_postoutcome_optimization": "No EF-based gene selection, weights, cutpoints, probe choice, background change or minimum-coverage change",
        },
        "conditional_primary_analysis": {
            "exposures": ["IFNA rank score standardized within selected eligible GSE11947 patients", "OXPHOS rank score standardized within those same patients"],
            "standardization": "z=(score-mean)/sampleSD; sampleSD uses ddof1, fixed analytic patients; two separate exposure models",
            "outcome": "Real numeric same-patient follow-up EF at original study's verified prespecified window and original unit; never silently substitute baseline EF or6 months",
            "models": ["EF_i=alpha_IFNA+beta_IFNA*zIFNA_i+error_i", "EF_i=alpha_OXPHOS+beta_OXPHOS*zOXPHOS_i+error_i"],
            "estimand": "Unadjusted linear association per1SD of the corresponding score among patients selected from extreme EF quartiles; original EF unit, percentage points only if original unit confirmed %",
            "uncertainty": "OLS slope with HC3 variance and two-sided t approximation df=n-2,95%CI; report approximation and small selected sample limits; retain wide/null intervals",
            "multiplicity": "The two primary exploratory slope tests form a separate2-test family; report raw two-sidedP and BH adjustedq, no substitutions by sensitivity significance",
            "covariates": "No baseline EF/age/sex adjustment until real fields and admissible design exist. Missing baseline EF means no independent recovery/prediction claim; no score-score joint model by default",
            "missing_clinical_outcomes": "No fabricated or imputedEF; any clinically unlinked/temporally ineligible case excluded by predeclared source rule with aggregate denominator recorded. Reassess background freeze only before first clinical effects if source gate changes sample eligibility",
            "selection_boundary": "Selected EF extremes and absent midrange support can make association predominantly between selected groups; no general AMI slope, recovery prediction, clinical increment, causal interpretation or ROC",
        },
        "prespecified_conditional_sensitivities": [
            "Descriptive original EF selection-group intercept adjustment: EF~zScore+original_group; equivalently center EF and score within original group and estimate common within-group slope. Group itself is EF-defined; do not interpret adjustment as eliminating clinical confounding or use significance to keep/drop primary models",
            "Report group-specific descriptive fit/precision only if group size and score variation permit, without using these fits to choose exposure/endpoint. Distinguish between-group from within-group signal",
            "For each primary fit, delete each patient in turn as an influence diagnostic, retain all eligible patients in primary, summarize slope direction/range without deleting cases because of EF or P",
            "If A selected, B may be fixed as scoring/missingness sensitivity before first effects; if B selected, A may be fixed as complete-background sensitivity. Never choose preferred method from effects",
        ],
        "source_and_method_questions_for_root": [
            "Timing/unit/method is still factual source HOLD and cannot be resolved by model opinion",
            "Original source explicitly defines processedVALUE log2(test/ref), so no sign flip by nominal channel needed; original four-slide aggregation operator remains unspecified but processed values are reused, not reconstructed",
            "Choose strict common observed gene background versus accepted gene-median imputation after reviewing aggregate content loss. If that choice materially changes scientific interpretation, use narrow Astra design review before freeze; none called in this preflight",
        ],
        "actual_execution": {"pathway_scores": 0, "clinical_effects": 0, "Astra_calls": 0, "figures": 0, "new_source_requests": 0},
    }
    (OUT / "CONDITIONAL_ANALYSIS_PROTOCOL_UNFROZEN.json").write_text(json.dumps(protocol, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = ["GSE11947本地评分准入预检（未使用EF关联结果、未冻结）", "输入指纹匹配原冻结HGNC与Hallmark；原稿/状态/模型清单未修改。", "原声明Hallmark97/200用于本研究目标交集；ROUND2的95/197是旧PBMC实测子集，仅核源身份，不作本轮默认。", "已知32EF及极端选样元数据，不称结局盲或盲验证。", f"唯一保守映射基因：{len(mapped_universe)}；独立表达对象32。", "逐患者重复探针取有限值中位数；全缺失保留缺失；未计算任何通路评分。"]
    for label, candidate in candidates.items():
        sizes = ", ".join(f"{name} {item['mapped_universe_members_n']}/{item['fixed_input_target_genes_n']}" for name, item in candidate["target_sets"].items())
        lines.append(f"{label}: background={candidate['universe_genes_n']}; {sizes}; missing_entries={candidate['universe_gene_sample_missing_entries_n']}")
    lines += ["候选A：全32共同有限值背景，固定可测目标子集，无填补；代价是丢失目标内容。", "候选B：至少29/32可测背景，同研究每基因观测中位数填补；代价是收缩/新增并列及未知缺失机制。", "候选C：逐患者可用基因排名，背景/目标成员不同，不建议作为主分析。", "两项候选暴露均拟按本研究样本SD标准化，分别作无调整EF关联；仅限EF极端选样谱系，不称恢复预测。", "拟定原EF选组调整/组内中心化描述性敏感性；组由EF定义，不能称消除临床混杂。", "临床采血与EF时序/单位/方法仍HOLD；协议未冻结，无评分、EF效应、正文或实际图片。", "原始比值尺度保持独立，不与PBMC直接合并；不依EF选基因。", "细节见SCORING_PREFLIGHT_AGGREGATE.json与CONDITIONAL_ANALYSIS_PROTOCOL_UNFROZEN.json。", ""]
    (OUT / "SCORING_PREFLIGHT_SUMMARY.txt").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"directory": str(OUT), "status": summary["status"], "mapped_genes_n": len(mapped_universe), "candidate_backgrounds": {label: {"N": row["universe_genes_n"], "target_n": {name: item["mapped_universe_members_n"] for name, item in row["target_sets"].items()}} for label, row in candidates.items()}, "pathway_scores": 0, "clinical_effects": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()

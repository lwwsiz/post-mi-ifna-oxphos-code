from pathlib import Path
import sys,json,gzip,io,collections,hashlib,datetime,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];V1=ROOT.parent/'pzxx_execution_20261004';sys.path.insert(0,str(V1/'_deps'))
import numpy as np,pandas as pd
sys.stdout.reconfigure(encoding='utf-8');OUT=ROOT/'analysis/independent_inputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tab(path,marker):
 with gzip.open(path,'rt') as f:
  for line in f:
   if line.startswith(marker):break
  rows=[]
  for line in f:
   if line.startswith('!') or line.startswith('^'):break
   if line.strip():rows.append(line)
 return pd.read_csv(io.StringIO(''.join(rows)),sep='\t',dtype=str,keep_default_na=False)
ann=tab(OUT/'GPL6106_family.soft.gz','!platform_table_begin');matrix=tab(OUT/'GSE61144_series_matrix.txt.gz','!series_matrix_table_begin').set_index('ID_REF').apply(pd.to_numeric)
h=pd.read_csv(V1/'inputs/hgnc_complete_set_20261004.txt',sep='\t',dtype=str,keep_default_na=False);approved=set(h.symbol);aliases=collections.defaultdict(set)
for _,row in h.iterrows():
 for field in ['prev_symbol','alias_symbol']:
  for x in row[field].split('|'):
   if x:aliases[x].add(row.symbol)
maps=[];ambiguous=0
for _,row in ann.iterrows():
 s=row.Symbol.strip();mapped=s if s in approved else (next(iter(aliases[s])) if len(aliases[s])==1 else None)
 if mapped is not None:maps.append({'probe':row.ID,'original_symbol':s,'gene':mapped})
 elif s:ambiguous+=1
maps=pd.DataFrame(maps).drop_duplicates('probe');common=maps[maps.probe.isin(matrix.index)].copy();data=matrix.loc[common.probe].copy();data.index=common.gene.to_numpy();genes=data.groupby(level=0,sort=True).median()
raw=(ROOT/'source_deepseek/raw/GSE61144_SOFT_brief.txt').read_text(encoding='utf-8');rows=[]
for block in raw.split('^SAMPLE = ')[1:]:
 lines=block.splitlines();sample=lines[0].strip();chars={}
 for line in lines:
  if line.startswith('!Sample_characteristics_ch1 = '):
   k,v=line.split(' = ',1)[1].split(': ',1);chars[k]=v
 def get(name):return next((line.split(' = ',1)[1] for line in lines if line.startswith('!Sample_'+name+' = ')),None)
 st=chars.get('subject group','');visit='postPCI_D7' if st=='patients with STEMI 7days after PCI' else ('prePCI' if st=='patients with STEMI (before PCI)' else 'control')
 rows.append({'sample':sample,'donor':chars['subject id'],'visit':visit,'tissue':chars.get('tissue'),'platform':get('platform_id'),'group':st,'source':'explicit !Sample_characteristics_ch1 subject id','title':get('title')})
meta=pd.DataFrame(rows).set_index('sample').loc[genes.columns];d=meta[meta.visit!='control'];assert len(d)==14 and d.donor.nunique()==7 and d.groupby('donor').visit.nunique().eq(2).all() and not d.reset_index().duplicated(['donor','visit']).any()
assert meta.platform.eq('GPL6106').all() and np.isfinite(genes.to_numpy()).all()
sets=json.loads((V1/'GENE_SETS_FROZEN.json').read_text());coordinated={nm:sorted(set(sets[nm]['measured_genes'])&set(genes.index)) for nm in ['IFNA','OXPHOS']}
outsets={nm:{'discovery_full_measured':len(sets[nm]['measured_genes']),'independent_declared_measured':len(set(sets[nm]['declared_genes'])&set(genes.index)),'coordinated_genes':gg,'missing_discovery_genes':sorted(set(sets[nm]['measured_genes'])-set(gg))} for nm,gg in coordinated.items()}
common.to_csv(OUT/'GPL6106_PROBE_GENE_MAP.csv',index=False);meta.to_csv(OUT/'GSE61144_SAMPLE_MANIFEST_LOCAL.csv');genes.to_pickle(OUT/'GSE61144_GENE_EXPRESSION.pkl');(OUT/'COORDINATED_GENE_SETS.json').write_text(json.dumps(outsets,ensure_ascii=False,indent=2),encoding='utf-8')
article=ET.parse(OUT/'PMC4536992_original.xml').getroot();evidence=[]
for e in article.iter('p'):
 s=''.join(e.itertext())
 if any(t in s.lower() for t in ['7 days after','quantile','log2','korea','catholic','6 v2','seoul']):evidence.append({'paragraph':s})
(OUT/'GSE61144_ORIGINAL_SOURCE_EXCERPTS.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
spec={'status':'SOURCE_GATE_CLEARED_FOR_LIMITED_INDEPENDENT_COMPUTATION','frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'effects_calculated_before_this_resolution':False,'source_identity':'GSE61144 / PMID26025919 / PMC4536992 / Park et al Oncotarget2015 Korean cohort','population':'7 STEMI real subject-id pairs before PCI and day7 after PCI; 14 arrays; ten healthy controls excluded; no pooling with Polish GSE59867','scale':'GEO metadata explicitly log2 transformed and quantile normalized using GenPlex3.0; detection p>0.1 at all arrays removed by source; no repeated normalization/log transform','platform':'GPL6106 Sentrix Human-6 v2; exact numeric ID_REF matches platform ID; Symbol unambiguously mapped via same HGNC snapshot, median per gene','n_probes':len(matrix),'n_platform_probes':len(ann),'n_exact_platform_ID_intersection':int(matrix.index.isin(ann.ID).sum()),'gene_universe':len(genes),'symbols_unmapped_or_ambiguous':ambiguous,'technical_repeats':'No duplicated explicit subject/visit; two different dates are biological repeats','independence_evidence':'Korean Catholic/Ajou clinical cohort in original authors/institutions versus Polish GSE59867 cohort and separate original investigators; no evidence of shared patients; different platform/tissue/windows. This is source-independence adjudication, not genome-based identity proof.','coordinated_primary_sets':outsets,'scoring':'Same rank formula; full independent gene universe. Coordinated membership is discovery-full measured genes intersect independent genes. Separate harmonized version on original full discovery universe; original V1 full-gene estimates unchanged.','model':'Conditional protocol original within/between decomposition + categorical visit + patient random intercept REML; lbfgs then Powell only on error/nonconvergence. Report boundary/nonconvergence; patient-level standardized FE diagnostic/bootstrap supplementary.','precision':'7 patients / 2 times; wide/unstable intervals expected and no binary success rule. Patient bootstrap 1000 seed20261004 planned as same appendix; every replicate reestimated/restandardized; degeneracies logged.','inputs_sha256':{n:sha(OUT/n) for n in ['GSE61144_series_matrix.txt.gz','GPL6106_family.soft.gz','PMC4536992_original.xml','GSE61144_SAMPLE_MANIFEST_LOCAL.csv','GSE61144_GENE_EXPRESSION.pkl','COORDINATED_GENE_SETS.json']}}
f=ROOT/'protocol/GSE61144_SOURCE_GATE_AND_ANALYSIS_RESOLUTION_FROZEN.json'
if f.exists():raise RuntimeError('Resolution frozen; refuse overwrite')
f.write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'gate':spec['status'],'genes':len(genes),'sets':{k:len(v) for k,v in coordinated.items()},'samples':len(d),'patients':d.donor.nunique(),'sha256':sha(f)}),flush=True)

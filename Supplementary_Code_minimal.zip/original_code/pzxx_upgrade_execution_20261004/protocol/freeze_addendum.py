from pathlib import Path
import sys,json,hashlib,datetime,urllib.request,collections
ROOT=Path(__file__).resolve().parents[1]; V1=ROOT.parent/'pzxx_execution_20261004'
sys.path.insert(0,str(V1/'_deps'))
import numpy as np,pandas as pd
OUT=ROOT/'protocol';OUT.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
sets=json.loads((V1/'GENE_SETS_FROZEN.json').read_text(encoding='utf-8'))
expr=pd.read_pickle(V1/'BULK_GENE_EXPRESSION.pkl');meta=pd.read_csv(V1/'PRIMARY_METADATA.csv',index_col=0,keep_default_na=False)
d=meta[meta.group.eq('STEMI')].copy();ct=d.groupby('donor').size();d=d[d.donor.isin(ct[ct>=2].index)]
assert len(d)==387 and d.donor.nunique()==108 and not d.reset_index().duplicated(['donor','visit']).any()
h=pd.read_csv(V1/'inputs/hgnc_complete_set_20261004.txt',sep='\t',dtype=str,keep_default_na=False);approved=set(h.symbol);aliases=collections.defaultdict(set)
for _,r in h.iterrows():
 for f in ['prev_symbol','alias_symbol']:
  for a in r[f].split('|'):
   if a:aliases[a].add(r.symbol)
logs=[]
for nm,long in [('IFNG','HALLMARK_INTERFERON_GAMMA_RESPONSE'),('TNFA_NFKB','HALLMARK_TNFA_SIGNALING_VIA_NFKB')]:
 p=OUT/(nm+'.json');url='https://www.gsea-msigdb.org/gsea/msigdb/download_geneset.jsp?geneSetName='+long+'&fileType=json'
 if not p.exists():
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=45) as r:p.write_bytes(r.read(2000000))
 o=json.loads(p.read_text());original=next(iter(o.values()))['geneSymbols'];mapped=[];unresolved=[]
 for g in original:
  if g in approved:mapped.append(g)
  elif len(aliases[g])==1:mapped.extend(aliases[g])
  else:unresolved.append(g)
 members=sorted(set(mapped));sets[nm]={'name':long,'declared_genes':members,'measured_genes':sorted(set(members)&set(expr.index)),'missing':sorted(set(members)-set(expr.index)),'unresolved_symbols':unresolved,'source_url':url,'source_sha256':sha(p)}
 logs.append({'name':nm,'url':url,'sha256':sha(p),'accessed':datetime.datetime.now(datetime.timezone.utc).isoformat()})
(OUT/'GENE_SETS_ADDENDUM_FROZEN.json').write_text(json.dumps(sets,ensure_ascii=False,indent=2),encoding='utf-8')
ex=expr.loc[:,d.index];mean=ex.mean(axis=1).to_numpy();sd=ex.std(axis=1,ddof=1).to_numpy();target=set(sets['IFNA']['measured_genes'])|set(sets['OXPHOS']['measured_genes']);exclude=expr.index.isin(target)
feas=[];chosen=None
for nb,ns in [(10,5),(10,3),(5,3),(5,2),(5,1),(3,1),(1,1)]:
 mb=np.asarray(pd.qcut(mean,nb,labels=False,duplicates='drop'),int) if nb>1 else np.zeros(len(expr),int)
 sb=np.asarray(pd.qcut(sd,ns,labels=False,duplicates='drop'),int) if ns>1 else np.zeros(len(expr),int)
 key=mb*ns+sb;required=collections.Counter(key[exclude]);pool=collections.Counter(key[~exclude]);ok=all(pool[k]>=v for k,v in required.items())
 feas.append({'mean_quantiles':nb,'SD_quantiles':ns,'feasible_disjoint_pair':ok,'minimum_pool_minus_combined_required':min(pool[k]-v for k,v in required.items())})
 if ok and chosen is None:chosen={'mean_quantiles':nb,'SD_quantiles':ns};chosenkey=key.copy()
assert chosen is not None
pd.DataFrame({'gene':expr.index,'mean_log2_expression':mean,'SD_log2_expression':sd,'stratum':chosenkey,'excluded_primary_target':exclude}).to_csv(OUT/'MATCHING_GENE_UNIVERSE.csv',index=False)
spec={'version':'posthoc-upgrade-1','frozen':True,'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_effects_seen_before_freeze':False,'V1_effects_known':True,'primary_question_and_comparison':'UNCHANGED; V1 unique IFNA within/between + visit + random patient-intercept model and its original unit preserved','population':{'resource':'GSE59867','samples':387,'patients':108,'inclusion':'STEMI identifiable patient with >=2 real visits; unchanged V1 sample ordering; no effect-driven exclusions','visits':['D0','discharge','M1','M6'],'technical_replicates':'No duplicate donor/visit in this included metadata'},'score':'V1 rank scoring, same full measured approved gene universe and primary gene sets','standardized_estimand':'Pearson correlation of the two score residuals after patient fixed effects and categorical visit; equivalent standardized FE coefficient. Supplement only; not replacement mixed-model estimate.','bootstrap':{'replicates':1000,'seed':20261004,'unit':'whole patient trajectories sampled with replacement; every replicate refits patient and visit adjustment and restandardizes','interval':'percentile 2.5/97.5; all degeneracy/failure reported'},'random_pairs':{'n':1000,'seed':20261004,'selection':'Exact size and joint mean-expression / SD-quantile stratum counts for each target; primary target union excluded; random sets disjoint within each pair; pairs drawn independently','chosen_strata':chosen,'feasibility':feas,'coarsening_rule':'Predeclared sequence 10x5,10x3,5x3,5x2,5x1,3x1,1x1; first feasible by joint pair demand selected without target association','diagnostic':'Two-sided fraction |residual r_random|>=|residual r_target|; Wilson interval for Monte Carlo fraction; not confirmatory P value. Original V1 100-pair slope 51% retained separately.','unmatched_features':['gene correlation structure','score variance','specific immune/cell mixture membership'],'report':['raw and adjusted average within-set gene pair correlation','raw score variance','patient/visit-adjusted score variance','actual stratum counts and mean/SD distribution differences','random-set pair overlap (zero by construction)']},'reference_family':{'names':['IFNG','TNFA_NFKB'],'interpretation':'Biologically related inflammatory reference pathways, not null negative controls','tests':'Each OXPHOS association with pathway within/between + visit + random patient intercept; original raw slope per 0.1 pathway score, residual standardized r and bootstrap CI; BH of these two raw mixed-model p values only','overlap':'Report all overlaps; do not remove IFNA/IFNG overlap post hoc'},'missingness':{'analysis':'111 identifiable STEMI D0 donors; audit availability of follow-up and real public baseline variables; describe target baseline scores by follow-up pattern; original complete-case result retained','weighting_gate':'Only if sufficient real clinical baseline predictors available and identifiable; scores alone do not establish ignorable missingness. No transcript/HF-label imputation.'},'singlecell':{'resource':'GSE269269 existing raw 10 donor matrices','unit':'donor','QC':'Same V1 >=200 detected genes, UMI>0, MT<=25%; donor libraries separately','doublet':'Scrublet raw UMI per donor, expected rate 0.06 unmeasured prior; defaults plus min_counts=2,min_cells=3,min_gene_variability_pctl=85,n_prin_comps=30, seed20261004; automatic threshold, save simulated scores/hist and predicted fraction; exclusion sensitivity only, accuracy unvalidated without ground truth','annotation':'Keep original coarse marker gates; independent held-out marker corroboration, not independent cell-label ground truth. No author/SingleR label validation claim.','held_out_panels':{'monocyte_like':['CTSS','LILRB1','TYROBP','FCER1G'],'T_like':['CD2','CD5','CD7','LCK'],'B_like':['CD19','CD22','CD37','CD74'],'NK_like':['PRF1','GZMB','XCL1','XCL2']},'report':'Donor lineage coverage and pseudobulk scores before/after predicted doublet exclusion; additional marker detection, donor contrasts descriptive; no cell-level inferential n','bulk_deconvolution':'Conditional only on validated suitable reference and identifiability; otherwise HOLD; retain V1 marker proxies and explicit cell-composition limitation'},'independent_validation':{'status_at_freeze':'HOLD pending bounded source gate','eligibility':'Real independent patient identity, >=2 times, blood tissue, mapped platform IDs and known scale before effects. No inferred numbering pairs.','estimator':'Same within/between + categorical visit + random patient intercept; smaller-time design precision and whole blood/PBMC differences documented','clinical':'True whole-cohort patient-linked continuous later LVEF with real measurement time required; no 17-extreme-patient prediction'},'multiplicity':'V1 primary and original IFI27/AHR family unchanged; only two inflammatory-reference tests form new exploratory BH family; localization/missingness/random diagnostics descriptive','inputs_sha256':{n:sha(V1/n) for n in ['BULK_GENE_EXPRESSION.pkl','PRIMARY_METADATA.csv','GENE_SETS_FROZEN.json','analysis_bulk.py','singlecell_localization.py']},'addendum_sets_sha256':sha(OUT/'GENE_SETS_ADDENDUM_FROZEN.json'),'matching_universe_sha256':sha(OUT/'MATCHING_GENE_UNIVERSE.csv'),'new_sources':logs}
p=OUT/'PROTOCOL_ADDENDUM_FROZEN.json'
if p.exists():raise RuntimeError('Frozen protocol exists; no overwrite')
p.write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'frozen_at':spec['frozen_at'],'protocol_sha256':sha(p),'strata':chosen,'samples':len(d),'patients':d.donor.nunique(),'new_set_coverage':{k:len(sets[k]['measured_genes']) for k in ['IFNG','TNFA_NFKB']}},ensure_ascii=False))

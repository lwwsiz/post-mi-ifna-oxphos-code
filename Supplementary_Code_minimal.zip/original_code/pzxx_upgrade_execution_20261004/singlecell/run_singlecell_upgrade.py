from pathlib import Path
import os,sys,json,tarfile,gzip,io,warnings,datetime,hashlib
ROOT=Path(__file__).resolve().parents[1];V1=ROOT.parent/'pzxx_execution_20261004';OUT=ROOT/'singlecell'
sys.path.insert(0,str(V1/'_deps'));sys.path.insert(0,str(OUT/'_deps'));os.environ['MPLBACKEND']='Agg'
import numpy as np,pandas as pd,scipy
from scipy.io import mmread
from scipy.stats import rankdata
import scrublet as scr
sys.stdout.reconfigure(encoding='utf-8')
protocol=json.loads((ROOT/'protocol/PROTOCOL_ADDENDUM_FROZEN.json').read_text(encoding='utf-8'));assert protocol['frozen'];spec=protocol['singlecell']
panels={'monocyte_like':['LYZ','CD14','FCGR3A','MS4A7'],'T_like':['CD3D','CD3E','TRAC'],'B_like':['MS4A1','CD79A','CD79B'],'NK_like':['NKG7','GNLY','KLRD1']};held=spec['held_out_panels']
assert not set(g for a in panels.values() for g in a)&set(g for a in held.values() for g in a)
sets=json.loads((V1/'GENE_SETS_FROZEN.json').read_text());bulk=pd.read_pickle(V1/'BULK_GENE_EXPRESSION.pkl').index
qc=[];pseudo=[];markers=[];coverage=[];ds=[];hist=[];celllog=[];features0=None
with tarfile.open(V1/'inputs/GSE269269_RAW.tar') as tar:
 for mem in sorted([m for m in tar.getmembers() if m.name.endswith('matrix.mtx.gz')],key=lambda x:x.name):
  prefix=mem.name.removesuffix('matrix.mtx.gz');donor=prefix.split('_')[1];group='NPR' if donor.startswith('NPR') else 'PR';feat=gzip.decompress(tar.extractfile(prefix+'features.tsv.gz').read()).decode().splitlines();syms=np.array([line.split('\t')[1] for line in feat]);ix={s:np.flatnonzero(syms==s) for s in set(syms)}
  if features0 is None:
   features0=syms;universe=np.array([s for s in bulk if s in ix and len(ix[s])==1]);uid=np.array([ix[s][0] for s in universe]);unames=set(universe)
  else:assert np.array_equal(features0,syms)
  mat=mmread(gzip.GzipFile(fileobj=tar.extractfile(mem))).tocsr();total=np.asarray(mat.sum(axis=0)).ravel();ng=np.asarray((mat>0).sum(axis=0)).ravel();mt=np.asarray(mat[np.char.startswith(syms.astype(str),'MT-')].sum(axis=0)).ravel();frac=np.divide(mt,total,out=np.ones_like(total,dtype=float),where=total>0);keep=(total>0)&(ng>=200)&(frac<=.25);rawN=len(total);mat=mat[:,keep].tocsc();nc=mat.shape[1]
  assert np.all(mat.data>=0) and np.allclose(mat.data,np.round(mat.data));det={name:np.asarray((mat[[ix[g][0] for g in genes]]>0).sum(axis=0)).ravel() for name,genes in panels.items()};cand={n:z>=2 for n,z in det.items()};cand['monocyte_like']&=np.asarray(mat[ix['LYZ'][0]].toarray()).ravel()>0;cand['NK_like']&=det['T_like']==0;num=np.vstack(list(cand.values())).sum(axis=0);label=np.full(nc,'unassigned',object);label[num>1]='ambiguous'
  for name,v in cand.items():label[v&(num==1)]=name
  prediction=np.zeros(nc,bool);scores=np.full(nc,np.nan);record={'donor':donor,'n_QC_cells':nc,'expected_doublet_prior':.06,'method':'Scrublet 0.2.3 exact sklearn nearest neighbors per library','threshold_policy':'Automatic minimum of simulated doublet distribution; no manual effect-guided changes','accuracy':'UNKNOWN no true doublet labels; homotypic doublets may be missed','library_boundary':'Deposited matrix is count data; raw droplet loading and prior filtering unknown'}
  try:
   with warnings.catch_warnings(record=True) as ww:
    warnings.simplefilter('always');s=scr.Scrublet(mat.T.tocsr(),expected_doublet_rate=.06,random_state=20261004);scores,pred=s.scrub_doublets(min_counts=2,min_cells=3,min_gene_variability_pctl=85,n_prin_comps=30,use_approx_neighbors=False,verbose=False)
   record['warnings']=[str(w.message) for w in ww]
   if pred is None:record['status']='SCORES_ONLY_THRESHOLD_FAILED'
   else:
    prediction=np.asarray(pred,bool);record.update(status='COMPUTED_UNVALIDATED_EXCLUSION_SENSITIVITY',auto_threshold=float(s.threshold_),predicted_doublets=int(prediction.sum()),predicted_fraction=float(prediction.mean()),sim_detectable_fraction=float(s.detectable_doublet_fraction_),implied_overall_fraction=float(s.overall_doublet_rate_))
   pd.DataFrame({'score':s.doublet_scores_sim_}).to_csv(OUT/(donor+'_SIMULATED_DOUBLET_SCORES.csv'),index=False)
   hh,edges=np.histogram(s.doublet_scores_sim_,bins=50)
   for i,n in enumerate(hh):hist.append({'donor':donor,'bin_low':edges[i],'bin_high':edges[i+1],'count':int(n),'threshold':record.get('auto_threshold',np.nan)})
  except Exception as e:record.update(status='METHOD_FAILED',error=type(e).__name__+': '+str(e))
  ds.append(record)
  for j in range(nc):celllog.append({'donor':donor,'local_QC_cell_index':j,'UMI':int(total[keep][j]),'detected_genes':int(ng[keep][j]),'MT_fraction':float(frac[keep][j]),'label':label[j],'doublet_score':float(scores[j]),'predicted_doublet':bool(prediction[j])})
  qc.append({'donor':donor,'group':group,'raw_cells':rawN,'QC_cells':nc,'predicted_doublets':int(prediction.sum()),'retained_after_computational_exclusion':int((~prediction).sum()),**{name:int((label==name).sum()) for name in list(panels)+['unassigned','ambiguous']}})
  for mode,allowed in [('V1_QC',np.ones(nc,bool)),('predicted_doublet_excluded',~prediction)]:
   for name in panels:
    select=(label==name)&allowed;nn=int(select.sum());coverage.append({'donor':donor,'group':group,'lineage':name,'mode':mode,'cells':nn,'library_QC_cells':nc,'proportion_of_QC_cells':nn/nc,'true_proportion':False})
    if nn==0:continue
    p=np.asarray(mat[uid][:,select].sum(axis=1)).ravel();ranks=rankdata(p);row={'donor':donor,'group':group,'lineage':name,'mode':mode,'cells':nn,'total_UMI':int(p.sum())}
    for nm in ['IFNA','OXPHOS']:
     members=sorted(set(sets[nm]['declared_genes'])&unames);ids=pd.Index(universe).get_indexer(members);m=len(ids);row[nm]=(ranks[ids].mean()-(m+1)/2)/(len(universe)-m)-.5
    pseudo.append(row)
    for expected,genes in held.items():
     for g in genes:
      if g not in ix:markers.append({'donor':donor,'mode':mode,'lineage':name,'expected_marker_lineage':expected,'gene':g,'status':'not_measured'});continue
      z=np.asarray(mat[ix[g][0]][:,select].toarray()).ravel();markers.append({'donor':donor,'mode':mode,'lineage':name,'expected_marker_lineage':expected,'gene':g,'status':'measured','positive_fraction':float((z>0).mean()),'mean_UMI':float(z.mean())})
  pd.DataFrame(qc).to_csv(OUT/'QC_BY_DONOR_UPGRADE.csv',index=False);pd.DataFrame(pseudo).to_csv(OUT/'DONOR_LINEAGE_UPGRADE_LOCAL.csv',index=False);pd.DataFrame(markers).to_csv(OUT/'HELDOUT_MARKER_DETECTION_LOCAL.csv',index=False);pd.DataFrame(coverage).to_csv(OUT/'DONOR_LINEAGE_COVERAGE.csv',index=False);(OUT/'DOUBLET_METHOD_BY_DONOR.json').write_text(json.dumps(ds,ensure_ascii=False,indent=2),encoding='utf-8');print(donor+' '+record['status']+' '+str(record.get('predicted_fraction')),flush=True)
df=pd.DataFrame(pseudo);old=pd.read_csv(V1/'singlecell/DONOR_LINEAGE_PSEUDOBULK_LOCAL.csv');check=df[df['mode']=='V1_QC'].merge(old,on=['donor','lineage'],suffixes=['_new','_V1']);assert len(check)==40 and np.allclose(check.IFNA_new,check.IFNA_V1) and np.allclose(check.OXPHOS_new,check.OXPHOS_V1)
pd.DataFrame(celllog).to_csv(OUT/'CELL_QC_DOUBLET_LOCAL.csv.gz',index=False);pd.DataFrame(hist).to_csv(OUT/'SIMULATED_DOUBLET_HISTOGRAM_SOURCE.csv',index=False)
summary=[]
for (mode,lin),f in df.groupby(['mode','lineage']):summary.append({'mode':mode,'lineage':lin,'donors':f.donor.nunique(),'total_cells':int(f.cells.sum()),'min_cells':int(f.cells.min()),'max_cells':int(f.cells.max()),'IFNA_mean':float(f.IFNA.mean()),'IFNA_SD':float(f.IFNA.std()),'OXPHOS_mean':float(f.OXPHOS.mean()),'OXPHOS_SD':float(f.OXPHOS.std())})
contrast=[]
for mode in ['V1_QC','predicted_doublet_excluded']:
 a=df[df['mode']==mode].pivot(index='donor',columns='lineage',values=['IFNA','OXPHOS'])
 for program in ['IFNA','OXPHOS']:
  for lineage in ['T_like','B_like','NK_like']:
   z=a[program]['monocyte_like']-a[program][lineage];contrast.append({'mode':mode,'program':program,'contrast':'monocyte_like minus '+lineage,'donors':int(z.notna().sum()),'mean_difference':float(z.mean()),'median_difference':float(z.median()),'min':float(z.min()),'max':float(z.max()),'unit':'donor-pseudobulk singscore; descriptive only'})
report={'status':'COMPLETE_DONOR_LEVEL_DESCRIPTIVE_UPGRADE_WITH_LIMITS','donors':10,'raw_cells':sum(x['raw_cells'] for x in qc),'QC_cells':sum(x['QC_cells'] for x in qc),'predicted_doublets':sum(x['predicted_doublets'] for x in qc),'doublet_method_status':{x['donor']:x['status'] for x in ds},'V1_pseudobulk_reproduction':'40 donor-lineage rows matched exactly within floating tolerance','summary':summary,'donor_paired_descriptive_contrasts':contrast,'annotation_evidence':'Held-out markers corroborate broad compartment identity, separate from original gate marker panel; they are not independent reference cell labels or an accuracy estimate. CTSS/TYROBP/FCER1G and CD7/PRF1 can span lineages; no exact state annotation claimed.','doublet_limit':'Computational threshold and 6% prior unvalidated; no manual threshold tuning; sensitivity exclusion does not establish singlet ground truth. Homotypic doublets and prior author filtering may limit detection.','biology_limit':'Acute 10-donor PBMC study; no controls or longitudinal followup; not independent patient-within validation. No cells as independent sample n.','bulk_deconvolution':{'status':'HOLD_NO_VALIDATED_IDENTIFIABLE_REFERENCE','reason':'10 AMI donor marker-gated PBMC compartments with unassigned/ambiguous cells and unvalidated proportions; no balanced independent reference or transport calibration. Do not treat derived fractions as measured bulk cell composition. V1 marker proxy sensitivity retained.'},'method_source':'https://github.com/swolock/scrublet','implementation':{'scrublet':'0.2.3','scipy':scipy.__version__,'numpy':np.__version__,'nearest_neighbors':'Exact sklearn; optional annoy unavailable and not required','new_images_generated':False}}
(OUT/'SINGLECELL_UPGRADE_SUMMARY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('DONE '+json.dumps({'donors':10,'QC_cells':report['QC_cells'],'predicted_doublets':report['predicted_doublets']}),flush=True)

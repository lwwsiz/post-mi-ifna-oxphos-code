from pathlib import Path
import sys,json,warnings,datetime,hashlib
ROOT=Path(__file__).resolve().parents[1];V1=ROOT.parent/'pzxx_execution_20261004';sys.path.insert(0,str(V1/'_deps'))
import numpy as np,pandas as pd
from scipy.stats import rankdata
import statsmodels.formula.api as smf
OUT=ROOT/'analysis';I=OUT/'independent_inputs';sys.stdout.reconfigure(encoding='utf-8')
resolution=ROOT/'protocol/GSE61144_SOURCE_GATE_AND_ANALYSIS_RESOLUTION_FROZEN.json';spec=json.loads(resolution.read_text());assert spec['effects_calculated_before_this_resolution']==False
sets=json.loads((I/'COORDINATED_GENE_SETS.json').read_text());expr=pd.read_pickle(I/'GSE61144_GENE_EXPRESSION.pkl');meta=pd.read_csv(I/'GSE61144_SAMPLE_MANIFEST_LOCAL.csv',index_col=0);external=meta[meta.visit!='control'].copy()
orig=pd.read_pickle(V1/'BULK_GENE_EXPRESSION.pkl');oldmeta=pd.read_csv(V1/'PRIMARY_METADATA.csv',index_col=0,keep_default_na=False);discovery=oldmeta[oldmeta.group=='STEMI'].copy();ct=discovery.groupby('donor').size();discovery=discovery[discovery.donor.isin(ct[ct>=2].index)]
def scores(E,D):
 ranks=rankdata(E.loc[:,D.index].to_numpy(),axis=0);N=len(E)
 for nm in ['IFNA','OXPHOS']:
  ii=E.index.get_indexer(sets[nm]['coordinated_genes']);m=len(ii);assert (ii>=0).all();D[nm]=(ranks[ii].mean(axis=0)-(m+1)/2)/(N-m)-.5
 return D
external=scores(expr,external);discovery=scores(orig,discovery)
def fit(D,label):
 D=D.copy();D['IFNA_between']=D.groupby('donor').IFNA.transform('mean');D['IFNA_within10']=(D.IFNA-D.IFNA_between)/.1;attempts=[];res=None
 for method in ['lbfgs','powell']:
  try:
   with warnings.catch_warnings(record=True) as ws:
    warnings.simplefilter('always');res=smf.mixedlm('OXPHOS ~ IFNA_within10 + IFNA_between + C(visit)',D,groups=D.donor).fit(reml=True,method=method,maxiter=300,disp=False)
   attempts.append({'method':method,'converged':bool(res.converged),'warnings':[str(w.message) for w in ws]})
   if res.converged:break
  except Exception as e:attempts.append({'method':method,'error':str(e)})
 row={'cohort':label,'samples':len(D),'patients':D.donor.nunique(),'gene_set_version':'separate cross-platform coordinated 92 IFNA /194 OXPHOS; V1 original unchanged','attempts':attempts,'unit':'OXPHOS rank score per 0.1 within-patient IFNA rank score','p_test':'asymptotic Wald z (especially limited in n=7)'}
 if res is not None and res.converged:
  ci=res.conf_int().loc['IFNA_within10'];row.update(status='MODEL_CONVERGED',beta=float(res.params['IFNA_within10']),ci_low=float(ci.iloc[0]),ci_high=float(ci.iloc[1]),p=float(res.pvalues['IFNA_within10']),random_intercept_variance=float(res.cov_re.iloc[0,0]),residual_variance=float(res.scale));(OUT/(label+'_COORDINATED_MODEL.txt')).write_text(res.summary().as_text(),encoding='utf-8')
 else:row['status']='MODEL_FAILED'
 codes,donors=pd.factorize(D.donor);ng=len(donors);S=D[['IFNA','OXPHOS']].to_numpy();H=pd.get_dummies(D.visit,drop_first=True,dtype=float).to_numpy()
 def within(M):
  means=np.zeros((ng,M.shape[1]));np.add.at(means,codes,M);means/=np.bincount(codes)[:,None];return M-means[codes]
 Hw=within(H);Sw=within(S)
 def adjust(w):
  b=np.linalg.lstsq(Hw*np.sqrt(w[:,None]),Sw*np.sqrt(w[:,None]),rcond=None)[0];return Sw-Hw@b
 def association(e,w):
  den=np.sqrt(np.sum(w*e[:,0]**2)*np.sum(w*e[:,1]**2));return float(np.sum(w*e[:,0]*e[:,1])/den) if den>1e-24 else np.nan
 w=np.ones(len(D));e=adjust(w);r=association(e,w);rng=np.random.default_rng(20261004);rr=[];fail=[]
 for k in range(1000):
  freq=np.bincount(rng.integers(0,ng,ng),minlength=ng);ww=freq[codes];ee=adjust(ww);b=association(ee,ww)
  if np.isfinite(b):rr.append(b)
  else:fail.append({'replicate':k+1,'reason':'zero residual variance with degenerate sampled patient trajectories'})
 pd.DataFrame({'r':rr}).to_csv(OUT/(label+'_COORDINATED_PATIENT_BOOTSTRAP.csv'),index=False)
 row['standardized_patient_visit_adjusted']={'r':r,'ci_low':float(np.quantile(rr,.025)),'ci_high':float(np.quantile(rr,.975)),'bootstrap_planned':1000,'successful':len(rr),'failures':fail,'method':'whole patient percentile with refit visit effect; especially unstable in 7 donors'}
 row['fixed_effect_raw_beta']=float(.1*np.dot(e[:,0],e[:,1])/np.dot(e[:,0],e[:,0]))
 D.to_csv(OUT/(label+'_COORDINATED_SCORES_LOCAL.csv'),encoding='utf-8-sig');return row
ext=fit(external,'GSE61144');disc=fit(discovery,'GSE59867');old=json.loads((V1/'analysis/RESULTS.json').read_text())['primary']
wide=external.pivot(index='donor',columns='visit',values=['IFNA','OXPHOS']);delta=pd.DataFrame({'donor':wide.index,'deltaIFNA':wide.IFNA.postPCI_D7-wide.IFNA.prePCI,'deltaOXPHOS':wide.OXPHOS.postPCI_D7-wide.OXPHOS.prePCI});delta.to_csv(OUT/'GSE61144_PAIRED_DELTAS_LOCAL.csv',index=False)
result={'status':'COMPLETE_LIMITED_INDEPENDENT_LONGITUDINAL_ANALYSIS','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_gate_resolution_sha256':hashlib.sha256(resolution.read_bytes()).hexdigest(),'external':ext,'harmonized_discovery':disc,'original_full_gene_primary_unchanged':old,'primary_gene_coverage':sets,'limitations':['Only seven independent Korean patients at prePCI/day7, versus 108 Polish patients with D0/discharge/M1/M6','Whole blood versus PBMC; different platform and scoring universe; coordinated membership does not calibrate score scales','Small-cohort Wald and bootstrap intervals are approximate and unstable; do not equate a same sign or P threshold with replication success','No available whole-cohort later LVEF or matched clinical prognosis'],'replication_judgment':'limited independent evidence; assess actual sign/magnitude/CI and transport differences alongside weak pathway specificity; not robust confirmed replication'}
(OUT/'INDEPENDENT_GSE61144_RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
up=json.loads((OUT/'RESULTS_UPGRADE.json').read_text());up['independent_validation']=result;(OUT/'RESULTS_UPGRADE.json').write_text(json.dumps(up,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'external':ext,'harmonized_discovery':disc},ensure_ascii=False),flush=True)

from pathlib import Path
import sys,json,warnings,hashlib,datetime,collections
ROOT=Path(__file__).resolve().parents[1];V1=ROOT.parent/'pzxx_execution_20261004';sys.path.insert(0,str(V1/'_deps'))
import numpy as np,pandas as pd
from scipy.stats import rankdata
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.proportion import proportion_confint
sys.stdout.reconfigure(encoding='utf-8');OUT=ROOT/'analysis';OUT.mkdir(exist_ok=True)
protocol=json.loads((ROOT/'protocol/PROTOCOL_ADDENDUM_FROZEN.json').read_text(encoding='utf-8'));assert protocol['frozen']
sets=json.loads((ROOT/'protocol/GENE_SETS_ADDENDUM_FROZEN.json').read_text(encoding='utf-8'));expr=pd.read_pickle(V1/'BULK_GENE_EXPRESSION.pkl')
meta=pd.read_csv(V1/'PRIMARY_METADATA.csv',index_col=0,keep_default_na=False);d=meta[meta.group.eq('STEMI')].copy();counts=d.groupby('donor').size();d=d[d.donor.isin(counts[counts>=2].index)].copy();assert len(d)==387 and d.donor.nunique()==108
genes=expr.index;X=expr.loc[:,d.index].to_numpy();ranks=rankdata(X,axis=0);N=len(genes)
def score(ids):return (ranks[ids].mean(axis=0)-(len(ids)+1)/2)/(N-len(ids))-.5
for nm,s in sets.items():d[nm]=score(genes.get_indexer(s['measured_genes']))
old=pd.read_csv(V1/'analysis/PRIMARY_SCORES_LOCAL.csv',index_col=0)
for nm in ['IFNA','OXPHOS']:assert np.allclose(d[nm],old.loc[d.index,nm],atol=1e-14)
donorcode,donors=pd.factorize(d.donor);ng=len(donors);visits=['D0','discharge','M1','M6'];H=np.column_stack([d.visit.eq(v) for v in visits[1:]]).astype(float)
def within(M):
 sums=np.zeros((ng,M.shape[1]));np.add.at(sums,donorcode,M);sums/=np.bincount(donorcode)[:,None];return M-sums[donorcode]
Hw=within(H)
def adjusted(M,weight=None):
 Mw=within(M);w=np.ones(len(d)) if weight is None else weight
 b=np.linalg.lstsq(Hw*np.sqrt(w[:,None]),Mw*np.sqrt(w[:,None]),rcond=None)[0]
 return Mw-Hw@b
S=d[['IFNA','OXPHOS','IFNG','TNFA_NFKB']].to_numpy();E=adjusted(S)
def corr(x,y,w=None):
 if w is None:w=np.ones(len(x))
 den=np.sqrt(np.sum(w*x*x)*np.sum(w*y*y));return float(np.sum(w*x*y)/den) if den>0 else np.nan
obs=corr(E[:,0],E[:,1]);rawfe=float(.1*np.dot(E[:,0],E[:,1])/np.dot(E[:,0],E[:,0]))
assert np.isclose(rawfe,json.loads((V1/'analysis/RESULTS.json').read_text())['random_control']['observed_fixed_effect_beta'])
rng=np.random.default_rng(20261004);boots=[];failures=[]
for k in range(1000):
 freq=np.bincount(rng.integers(0,ng,ng),minlength=ng);w=freq[donorcode];e=adjusted(S,w)
 vals=[corr(e[:,j],e[:,1],w) for j in [0,2,3]]
 if np.isfinite(vals).all():boots.append(vals)
 else:failures.append({'replicate':k+1,'reason':'zero adjusted score variance'})
B=np.array(boots);pd.DataFrame(B,columns=['IFNA_OXPHOS_r','IFNG_OXPHOS_r','TNFA_NFKB_OXPHOS_r']).to_csv(OUT/'PATIENT_STANDARDIZED_BOOTSTRAP.csv',index=False)
def estimate(j,col):return {'r':corr(E[:,j],E[:,1]),'ci_low':float(np.quantile(B[:,col],.025)),'ci_high':float(np.quantile(B[:,col],.975)),'CI':'1000 whole-patient percentile bootstrap with reestimated patient/visit effects and SD','residual_predictor_SD':float(np.std(E[:,j],ddof=1)),'residual_OXPHOS_SD':float(np.std(E[:,1],ddof=1))}
main=estimate(0,0);main['raw_FE_beta_per_0_1_IFNA']=rawfe
print('STANDARDIZED '+json.dumps(main),flush=True)
ref=[];overlaps={}
for j,(nm,col) in enumerate([('IFNG',1),('TNFA_NFKB',2)],start=2):
 row=estimate(j,col);d[nm+'_between']=d.groupby('donor')[nm].transform('mean');d[nm+'_within10']=(d[nm]-d[nm+'_between'])/.1
 attempts=[];res=None
 for method in ['lbfgs','powell']:
  try:
   with warnings.catch_warnings(record=True) as ww:
    warnings.simplefilter('always');res=smf.mixedlm('OXPHOS ~ '+nm+'_within10 + '+nm+'_between + C(visit)',d,groups=d.donor).fit(reml=True,method=method,maxiter=300,disp=False)
   attempts.append({'method':method,'converged':bool(res.converged),'warnings':[str(w.message) for w in ww]})
   if res.converged:break
  except Exception as e:attempts.append({'method':method,'error':str(e)})
 row.update(name=nm,measured_genes=len(sets[nm]['measured_genes']),fit_attempts=attempts,interpretation='inflammatory reference, not biologic null negative control')
 if res is not None and res.converged:
  term=nm+'_within10';ci=res.conf_int().loc[term];row.update(status='COMPLETE',beta=float(res.params[term]),ci_low_raw=float(ci.iloc[0]),ci_high_raw=float(ci.iloc[1]),p=float(res.pvalues[term]),unit='OXPHOS raw score per 0.1 within-patient reference score')
 else:row['status']='MODEL_FAILED'
 ref.append(row)
 for target in ['IFNA','OXPHOS']:overlaps[nm+'_'+target]=sorted(set(sets[nm]['measured_genes'])&set(sets[target]['measured_genes']))
valid=[r for r in ref if 'p' in r]
for r,q in zip(valid,multipletests([r['p'] for r in valid],method='fdr_bh')[1]):r['p_BH_new_two_reference_family']=float(q)
features=pd.read_csv(ROOT/'protocol/MATCHING_GENE_UNIVERSE.csv');assert np.array_equal(features.gene,genes)
key=features.stratum.to_numpy();eligible=~features.excluded_primary_target.to_numpy();pools={s:np.flatnonzero((key==s)&eligible) for s in np.unique(key)}
targetids={nm:genes.get_indexer(sets[nm]['measured_genes']) for nm in ['IFNA','OXPHOS']};demand={nm:collections.Counter(key[ii]) for nm,ii in targetids.items()}
GX=adjusted(X.T).T
def standard(M):
 z=M-M.mean(axis=1,keepdims=True);norm=np.sqrt(np.sum(z*z,axis=1));return np.divide(z,norm[:,None],out=np.zeros_like(z),where=norm[:,None]>0),norm
Zraw,normraw=standard(X);Zadj,normadj=standard(GX)
def diagnostics(ii,sc):
 m=len(ii);den=m*(m-1)
 return {'mean_log2_expression':float(features.mean_log2_expression.iloc[ii].mean()),'mean_gene_SD':float(features.SD_log2_expression.iloc[ii].mean()),'mean_gene_pair_corr_raw':float((np.sum(Zraw[ii].sum(axis=0)**2)-np.sum(normraw[ii]>0))/den),'mean_gene_pair_corr_adjusted':float((np.sum(Zadj[ii].sum(axis=0)**2)-np.sum(normadj[ii]>0))/den),'score_variance_raw':float(np.var(sc,ddof=1)),'score_variance_adjusted':float(np.var(adjusted(sc[:,None])[:,0],ddof=1))}
targets={nm:diagnostics(ii,d[nm].to_numpy()) for nm,ii in targetids.items()}
rng=np.random.default_rng(20261004);random=[];randomgenes=[]
for k in range(1000):
 a=[];b=[]
 for st in sorted(pools):
  needa=demand['IFNA'][st];needb=demand['OXPHOS'][st];ids=rng.choice(pools[st],needa+needb,replace=False);a.extend(ids[:needa]);b.extend(ids[needa:])
 a=np.array(a,int);b=np.array(b,int);assert not np.intersect1d(a,b).size
 assert collections.Counter(key[a])==demand['IFNA'] and collections.Counter(key[b])==demand['OXPHOS']
 sx=score(a);sy=score(b);ee=adjusted(np.column_stack([sx,sy]));row={'pair':k+1,'r':corr(ee[:,0],ee[:,1]),'raw_beta_per_0_1_random_x':float(.1*np.dot(ee[:,0],ee[:,1])/np.dot(ee[:,0],ee[:,0])),'set_overlap':0}
 for nm,ii,sc in [('x',a,sx),('y',b,sy)]:
  row.update({nm+'_'+field:value for field,value in diagnostics(ii,sc).items()})
 random.append(row);randomgenes.append({'pair':k+1,'x':genes[a].tolist(),'y':genes[b].tolist()})
 if (k+1)%250==0:print('RANDOM '+str(k+1),flush=True)
rr=pd.DataFrame(random);rr.to_csv(OUT/'MATCHED_RANDOM_PAIR_DIAGNOSTICS.csv',index=False);(OUT/'MATCHED_RANDOM_PAIR_GENES.json').write_text(json.dumps(randomgenes),encoding='utf-8')
exceed=int((rr.r.abs()>=abs(obs)).sum());mc=proportion_confint(exceed,1000,alpha=.05,method='wilson')
summary={'n_pairs':1000,'seed':20261004,'diagnostic_target_r':obs,'fraction_abs_random_r_at_least_target':exceed/1000,'exceeding_pairs':exceed,'Monte_Carlo_Wilson95':[float(x) for x in mc],'random_r_median':float(rr.r.median()),'random_r_q025':float(rr.r.quantile(.025)),'random_r_q975':float(rr.r.quantile(.975)),'matching':'Exact size and joint 10 mean-expression by 5 gene-SD stratum counts; disjoint pair, target union excluded','not_matched':['gene pair correlation','score variance','cell type membership'],'target_diagnostics':targets,'reference_distribution_summary':{c:{'median':float(rr[c].median()),'q025':float(rr[c].quantile(.025)),'q975':float(rr[c].quantile(.975))} for c in rr if c.startswith(('x_','y_'))},'inference_limit':'Monte Carlo uncertainty conditional on sampling scheme; this is a specificity diagnostic, not a confirmatory pathway P value'}
allsc=pd.read_csv(V1/'analysis/ALL_SAMPLE_SCORES.csv',index_col=0);base=allsc[(allsc.group=='STEMI')&(allsc.visit=='D0')].copy();assert len(base)==111
patterns=meta[meta.group=='STEMI'].groupby('donor').visit.agg(lambda x:'|'.join(v for v in visits if v in set(x)));base['visit_pattern']=base.donor.map(patterns);miss=[]
for v in visits[1:]:
 available=set(meta[(meta.group=='STEMI')&(meta.visit==v)].donor);base['has_'+v]=base.donor.isin(available)
 for status in [True,False]:
  f=base[base['has_'+v]==status];miss.append({'followup':v,'observed':status,'n':len(f),'IFNA_baseline_mean':float(f.IFNA.mean()),'IFNA_baseline_SD':float(f.IFNA.std()),'OXPHOS_baseline_mean':float(f.OXPHOS.mean()),'OXPHOS_baseline_SD':float(f.OXPHOS.std())})
pd.DataFrame(miss).to_csv(OUT/'FOLLOWUP_BASELINE_AUDIT.csv',index=False);base.to_csv(OUT/'BASELINE_FOLLOWUP_PATTERNS_LOCAL.csv',encoding='utf-8-sig')
char=[json.loads(v) for v in meta.characteristics];realfields=sorted(set(k for row in char for k in row));clinical_candidates=[k for k in realfields if any(t in k.lower() for t in ['age','sex','gender','lvef','ejection','nt-pro','bnp','diabet','smok'])]
clinical={'status':'HOLD_COMPLETE_PATIENT_LINKED_CONTINUOUS_PHENOTYPE','real_metadata_characteristic_keys':realfields,'candidate_clinical_keys':clinical_candidates,'true_whole_cohort_LVEF_available':False,'HF_extreme_subset_only':'17 patients (9 HF/8 non-HF) in V1; descriptive only; missing HF label not absence of HF','no_weighting_reason':'Public sample metadata lacks adequate real baseline clinical predictors; baseline transcript scores alone do not justify missing-at-random or clinically interpretable weighting','reopen':'Actual full-cohort patient-visit-linked continuous LVEF and measurement times supplied/verified'}
(OUT/'CLINICAL_PHENOTYPE_AUDIT.json').write_text(json.dumps(clinical,ensure_ascii=False,indent=2),encoding='utf-8')
results={'status':'COMPLETE_AVAILABLE_APPENDIX_ANALYSES_WITH_LOCAL_HOLDS','protocol_sha256':hashlib.sha256((ROOT/'protocol/PROTOCOL_ADDENDUM_FROZEN.json').read_bytes()).hexdigest(),'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'n_patients':108,'n_samples':387,'V1_primary_retained':json.loads((V1/'analysis/RESULTS.json').read_text())['primary'],'V1_original_random_diagnostic_retained':json.loads((V1/'analysis/RESULTS.json').read_text())['random_control'],'standardized_association':main,'patient_bootstrap':{'planned':1000,'successful':len(boots),'failed':len(failures),'failures':failures},'inflammatory_references':ref,'gene_overlap':overlaps,'matched_random_diagnostic':summary,'missing_followup':miss,'baseline_visit_patterns':base.visit_pattern.value_counts().to_dict(),'weighting':'SKIPPED_CONDITIONAL_NO_REAL_CLINICAL_PREDICTORS','clinical_bridge':clinical,'independent_validation':'PENDING_SOURCE_ADJUDICATION','claim_boundary':'Post hoc supplementary transcription-score covariance; no IFN specificity, respiratory function, causal mechanism or prediction established.'}
(OUT/'RESULTS_UPGRADE.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');d.to_csv(OUT/'UPGRADE_ALL_PRIMARY_SCORES_LOCAL.csv',encoding='utf-8-sig');print('DONE '+json.dumps({'r':main,'random':summary['fraction_abs_random_r_at_least_target'],'references':ref}),flush=True)

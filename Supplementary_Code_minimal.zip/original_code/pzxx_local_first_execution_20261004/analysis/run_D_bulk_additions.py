from pathlib import Path
import sys,json,warnings,datetime,hashlib
ROOT=Path(__file__).resolve().parents[1];U=ROOT.parent/'pzxx_upgrade_execution_20261004';V1=ROOT.parent/'pzxx_execution_20261004';sys.path.insert(0,str(V1/'_deps'))
import numpy as np,pandas as pd
from scipy.stats import chi2,norm,t
import statsmodels.formula.api as smf
OUT=ROOT/'analysis';sys.stdout.reconfigure(encoding='utf-8');protocol=json.loads((ROOT/'protocol/ROUND2_DE_PROTOCOL_FROZEN.json').read_text(encoding='utf-8'));assert protocol['frozen'];genespec=json.loads((ROOT/'protocol/ROUND2_GENE_SETS_AND_UNIVERSES_FROZEN.json').read_text(encoding='utf-8'))
d=pd.read_csv(U/'analysis/UPGRADE_ALL_PRIMARY_SCORES_LOCAL.csv',index_col=0);d['visit']=pd.Categorical(d.visit,categories=['D0','discharge','M1','M6']);assert len(d)==387 and d.donor.nunique()==108
d['IFNA_between']=d.groupby('donor').IFNA.transform('mean');d['IFNA_within10']=(d.IFNA-d.IFNA_between)/.1
formula='OXPHOS ~ IFNA_within10 * C(visit) + IFNA_between';attempts=[];res=None
for method in ['lbfgs','powell']:
 try:
  with warnings.catch_warnings(record=True) as ws:
   warnings.simplefilter('always');res=smf.mixedlm(formula,d,groups=d.donor).fit(reml=True,method=method,maxiter=300,disp=False)
  attempts.append({'method':method,'converged':bool(res.converged),'warnings':[str(w.message) for w in ws]})
  if res.converged:break
 except Exception as e:attempts.append({'method':method,'error':str(e)})
interaction={'formula':formula+' + (1|donor)','status':'MODEL_FAILED','attempts':attempts,'exploratory':True,'patients':108,'samples':387,'score':'Original frozen singscore','primary_average_effect_replaced':False};slopes=[]
if res is not None and res.converged:
 terms=['IFNA_within10:C(visit)[T.'+v+']' for v in ['discharge','M1','M6']];coef=res.params.loc[terms].to_numpy();cov=res.cov_params().loc[terms,terms].to_numpy();rank=int(np.linalg.matrix_rank(cov));W=float(coef@np.linalg.pinv(cov)@coef);p=float(chi2.sf(W,rank));interaction.update(status='MODEL_CONVERGED',global_wald_chi2=W,df=rank,p_raw=p,p_Bonferroni_two_question_bound=min(1,2*p),random_intercept_variance=float(res.cov_re.iloc[0,0]),residual_variance=float(res.scale),test='Joint3interaction Waldchi-square; not REML likelihoodratio')
 for v in ['D0','discharge','M1','M6']:
  L=pd.Series(0.,index=res.params.index);L['IFNA_within10']=1
  if v!='D0':L['IFNA_within10:C(visit)[T.'+v+']']=1
  beta=float(L@res.params);se=float(np.sqrt(L@res.cov_params()@L));slopes.append({'visit':v,'beta_per_0_1_IFNA':beta,'SE':se,'ci_low':beta-norm.ppf(.975)*se,'ci_high':beta+norm.ppf(.975)*se,'n_patients':d[d.visit==v].donor.nunique(),'CI':'normalWald95;exploratory,notvisitwiseconfirmatory'})
 (OUT/'D_INTERACTION_MIXED_MODEL.txt').write_text(res.summary().as_text(),encoding='utf-8')
pd.DataFrame(slopes).to_csv(OUT/'D_VISIT_SPECIFIC_SLOPES.csv',index=False)
# Prespecified fixedpatient clustered technical check when the randomfit warns of boundary or fails.
if res is None or not res.converged or any('boundary' in w.lower() for a in attempts for w in a.get('warnings',[])):
 fe=smf.ols('OXPHOS ~ IFNA_within10 * C(visit) + C(donor)',d).fit(cov_type='cluster',cov_kwds={'groups':d.donor,'use_correction':True},use_t=True)
 terms=['IFNA_within10:C(visit)[T.'+v+']' for v in ['discharge','M1','M6']];R=np.zeros((3,len(fe.params)))
 for j,term in enumerate(terms):R[j,fe.params.index.get_loc(term)]=1
 wt=fe.wald_test(R,use_f=True,scalar=True);interaction['clustered_fixedpatient_technical_check']={'F':float(wt.statistic),'df_num':float(wt.df_num),'df_den':float(wt.df_denom),'p':float(wt.pvalue),'status':'PREDECLARED_WARNING_TRIGGERED_SENSITIVITY','reason':'Raw-score absolute-variance boundary warnings do not by themselves prove a zero randomvariance; both estimates retained'}
 fes=[]
 for v in ['D0','discharge','M1','M6']:
  L=pd.Series(0.,index=fe.params.index);L['IFNA_within10']=1
  if v!='D0':L['IFNA_within10:C(visit)[T.'+v+']']=1
  b=float(L@fe.params);se=float(np.sqrt(L@fe.cov_params()@L));crit=t.ppf(.975,107);fes.append({'visit':v,'beta_per_0_1_IFNA':b,'ci_low':b-crit*se,'ci_high':b+crit*se,'SE':se,'df':107})
 pd.DataFrame(fes).to_csv(OUT/'D_VISIT_SLOPES_CLUSTERED_FE_SENSITIVITY.csv',index=False)
old=json.loads((U/'analysis/RESULTS_UPGRADE.json').read_text(encoding='utf-8'));joint=pd.read_csv(U/'analysis/PATIENT_STANDARDIZED_BOOTSTRAP.csv');assert len(joint)==1000
delta=joint.IFNA_OXPHOS_r-joint.IFNG_OXPHOS_r;diff={'estimand':'rIFNA-OXPHOS minus rIFNG-OXPHOS, both patient+visit residual correlations','r_IFNA':old['standardized_association']['r'],'r_IFNG':next(v for v in old['inflammatory_references'] if v['name']=='IFNG')['r'],'delta':old['standardized_association']['r']-next(v for v in old['inflammatory_references'] if v['name']=='IFNG')['r'],'ci_low':float(delta.quantile(.025)),'ci_high':float(delta.quantile(.975)),'replicates':len(joint),'method':'Pairedpercentile CI from same prior1000wholepatientclusterbootstrap columns; both correlations recomputed together','P':'NOT_CONSTRUCTED_INTERVAL_ONLY','BH':'NOT_CONSTRUCTED_INCOMPATIBLE_MISSING_P; globalinteraction rawP and conservativeBonferroni2P reported separately, delta95CI not familywise','score_gene_overlap':old['gene_overlap']['IFNG_IFNA']};joint2=joint[['IFNA_OXPHOS_r','IFNG_OXPHOS_r']].copy();joint2['paired_delta_r']=delta;joint2.to_csv(OUT/'D_PAIRED_IFNA_IFNG_DELTA_BOOTSTRAP.csv',index=False)
expr=pd.read_pickle(V1/'BULK_GENE_EXPRESSION.pkl');union=sorted(set(genespec['bulk_primary_sets']['IFNA'])|set(genespec['bulk_primary_sets']['OXPHOS']));X=expr.loc[union,d.index].to_numpy();idx=pd.Index(union);members={nm:idx.get_indexer([g for g in genespec['bulk_primary_sets'][nm] if g not in genespec['alternative_score_zero_SD_excluded'][nm]]) for nm in ['IFNA','OXPHOS']};means=X.mean(axis=1);SD=X.std(axis=1,ddof=1);assert (SD>1e-12).all();Z=(X-means[:,None])/SD[:,None];altS=np.column_stack([Z[members[nm]].mean(axis=0) for nm in ['IFNA','OXPHOS']]);codes,donors=pd.factorize(d.donor);ng=len(donors);H=np.column_stack([d.visit.eq(v) for v in ['discharge','M1','M6']]).astype(float)
def within(M):
 s=np.zeros((ng,M.shape[1]));np.add.at(s,codes,M);s/=np.bincount(codes)[:,None];return M-s[codes]
Hw=within(H);Xw=within(X.T).T
def adjust(M,w):return M-Hw@np.linalg.lstsq(Hw*np.sqrt(w[:,None]),M*np.sqrt(w[:,None]),rcond=None)[0]
def corr(e,w):
 den=np.sqrt(np.sum(w*e[:,0]**2)*np.sum(w*e[:,1]**2));return float(np.sum(w*e[:,0]*e[:,1])/den) if den>1e-24 else np.nan
pointE=adjust(within(altS),np.ones(len(d)));point=corr(pointE,np.ones(len(d)));rng=np.random.default_rng(20261004);boots=[];failures=[];bootstrap_first_calibration=None
for k in range(1000):
 freq=np.bincount(rng.integers(0,ng,ng),minlength=ng);w=freq[codes];ns=w.sum();mu=X@w/ns;var=((X-mu[:,None])**2)@w/(ns-1);sd=np.sqrt(var)
 if (sd<=1e-12).any() or (~np.isfinite(sd)).any():failures.append({'replicate':k+1,'reason':'bootstrapgenezeroSD'});continue
 Sw=np.column_stack([(Xw[members[nm]]/sd[members[nm],None]).mean(axis=0) for nm in ['IFNA','OXPHOS']]);e=adjust(Sw,w);b=corr(e,w)
 if np.isfinite(b):boots.append({'replicate':k+1,'r':b,'resampled_rows':int(ns)})
 else:failures.append({'replicate':k+1,'reason':'adjustedscoredegenerate'})
 if k==0:bootstrap_first_calibration={'weighted_gene_mean':mu.tolist(),'weighted_gene_SD':sd.tolist(),'drawn_donor_indices':np.repeat(np.arange(ng),freq).tolist(),'r':b}
bb=pd.DataFrame(boots);bb.to_csv(OUT/'D_ALTERNATIVE_GENEZ_PATIENT_BOOTSTRAP.csv',index=False);da=d[['donor','visit']].copy();da['IFNA_geneZ_mean']=altS[:,0];da['OXPHOS_geneZ_mean']=altS[:,1];da.to_csv(OUT/'D_ALTERNATIVE_GENEZ_SCORES_LOCAL.csv');pd.DataFrame({'gene':union,'sample_mean_log2':means,'sample_SD_log2':SD,'in_IFNA':[g in genespec['bulk_primary_sets']['IFNA'] for g in union],'in_OXPHOS':[g in genespec['bulk_primary_sets']['OXPHOS'] for g in union]}).to_csv(OUT/'D_ALTERNATIVE_GENEZ_CALIBRATION.csv',index=False)
alternative={'method':'Onlyone alternative:mean of gene-log2expression zscores; originalsets, primary387calibration','r':point,'ci_low':float(bb.r.quantile(.025)),'ci_high':float(bb.r.quantile(.975)),'planned_bootstrap':1000,'successful':len(boots),'failures':failures,'bootstrap_gene_calibration':'Recomputed genemean/sampleSD within every wholepatient draw; same draw frequency per wholetrajectory; sample rows can vary','unit':'standardized adjustedPearsonr; not raw rankscore beta','zero_SD_excluded':genespec['alternative_score_zero_SD_excluded'],'formal_P':'NOT_ADDED_SCORING_DIAGNOSTIC','claim':'Alternative scoring sensitivity, no newprimary/clinicalreplication or specificity test'}
# Independent explicit duplicated-cluster validation for alternative bootstrap replicate1.
rng=np.random.default_rng(20261004);chosen=rng.integers(0,ng,ng);ff=[];colids=[]
for j,k in enumerate(chosen):
 inds=np.flatnonzero(codes==k);f=d.iloc[inds][['visit']].copy();f['cluster']=str(j);ff.append(f);colids.extend(inds)
bframe=pd.concat(ff,ignore_index=True);XB=X[:,colids];ZB=(XB-XB.mean(axis=1,keepdims=True))/XB.std(axis=1,ddof=1)[:,None];SB=np.column_stack([ZB[members[nm]].mean(axis=0) for nm in ['IFNA','OXPHOS']]);design=np.column_stack([np.ones(len(bframe)),pd.get_dummies(bframe.cluster,drop_first=True,dtype=float).to_numpy(),pd.get_dummies(bframe.visit,drop_first=True,dtype=float).to_numpy()]);Q=np.linalg.qr(design,mode='reduced')[0];EB=SB-Q@(Q.T@SB);explicit=float(EB[:,0]@EB[:,1]/np.sqrt((EB[:,0]@EB[:,0])*(EB[:,1]@EB[:,1])));assert np.isclose(explicit,bb.r.iloc[0],atol=1e-12)
results={'status':'COMPLETE_PRESPECIFIED_POSTHOC_D','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_protocol_sha256':hashlib.sha256((ROOT/'protocol/ROUND2_DE_PROTOCOL_FROZEN.json').read_bytes()).hexdigest(),'interaction':interaction,'visit_slopes':slopes,'IFNA_IFNG_direct_difference':diff,'alternative_score':alternative,'numerical_check':{'alternative_firstbootstrap_explicit_duplicateclusters_r':explicit,'weighted_bootstrap_r':float(bb.r.iloc[0]),'agreement':True},'original_results':'AllV1/firstupgrade primary andnegatives/old200/new1000 bootstrap/random81.6 retained; no newrandom controls','limits':'Posthoc exploratorystage differences and scoring sensitivity; no mechanistic/clinical/prognostic assertions'};(OUT/'D_BULK_ADDITIONS_RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(results,ensure_ascii=False),flush=True)

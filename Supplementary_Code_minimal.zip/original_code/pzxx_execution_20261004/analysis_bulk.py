"""Execute the frozen patient-level public-transcriptome analysis; no model-selected outcomes."""
from pathlib import Path
import sys,json,warnings,datetime,time
O=Path(__file__).resolve().parent;sys.path.insert(0,str(O/'_deps'))
import numpy as np,pandas as pd
from scipy.stats import rankdata
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
sys.stdout.reconfigure(encoding='utf-8')
SEED=20261004
if not (O/'GATE_DECISION.json').exists():raise RuntimeError('Source gate not decided; no effects')
gate=json.loads((O/'GATE_DECISION.json').read_text(encoding='utf-8'))
if not gate['primary_analysis_authorized']:raise RuntimeError('Primary gate not open')
out=O/'analysis';out.mkdir(exist_ok=True)
expr=pd.read_pickle(O/'BULK_GENE_EXPRESSION.pkl');sets=json.loads((O/'GENE_SETS_FROZEN.json').read_text(encoding='utf-8'))
meta=pd.read_csv(O/'PRIMARY_METADATA.csv',index_col=0,keep_default_na=False)
N=len(expr);ranks=rankdata(expr.to_numpy(),axis=0,method='average')
def score(members):
 idx=expr.index.get_indexer(members);assert (idx>=0).all()
 m=len(idx);return (ranks[idx].mean(axis=0)-(m+1)/2)/(N-m)-.5
for name,s in sets.items():meta[name]=score(s['measured_genes'])
for gene in ['IFI27','AHR']:
 if gene in expr.index:meta[gene]=expr.loc[gene].to_numpy()
meta['visit']=pd.Categorical(meta['visit'],categories=['D0','discharge','M1','M6','CAD'],ordered=True)
d=meta[meta.group=='STEMI'].copy();counts=d.groupby('donor').size();d=d[d.donor.isin(counts[counts>=2].index)].copy()
d['visit']=d['visit'].cat.remove_unused_categories()
assert len(d)==387 and d.donor.nunique()==108
assert not d.reset_index().duplicated(['donor','visit']).any()
def decompose(frame,name):
 frame[name+'_between']=frame.groupby('donor')[name].transform('mean')
 frame[name+'_within10']=(frame[name]-frame[name+'_between'])/.1
decompose(d,'IFNA')
formula='OXPHOS ~ IFNA_within10 + IFNA_between + C(visit)'
def fit(frame,extra='',term='IFNA_within10'):
 attempts=[];res=None
 for method in ['lbfgs','powell']:
  try:
   with warnings.catch_warnings(record=True) as ws:
    warnings.simplefilter('always');m=smf.mixedlm(formula+extra,frame,groups=frame['donor']);res=m.fit(reml=True,method=method,maxiter=300,disp=False)
   attempts.append({'method':method,'converged':bool(res.converged),'warnings':[str(w.message) for w in ws]})
   if res.converged:break
  except Exception as e:attempts.append({'method':method,'error':str(e)})
 if res is None or not res.converged:raise RuntimeError('Mixed model did not converge: '+str(attempts))
 ci=res.conf_int().loc[term]
 val={'beta':float(res.params[term]),'ci_low':float(ci.iloc[0]),'ci_high':float(ci.iloc[1]),'p':float(res.pvalues[term]),
      'n_samples':len(frame),'n_patients':frame.donor.nunique(),'effect_unit':'OXPHOS singscore per 0.1-unit IFNA within-patient score',
      'random_intercept_variance':float(res.cov_re.iloc[0,0]),'residual_variance':float(res.scale),'attempts':attempts}
 return res,val
def olsresult(res,term,frame,label):
 ci=res.conf_int().loc[term];return {'label':label,'beta':float(res.params[term]),'ci_low':float(ci.iloc[0]),'ci_high':float(ci.iloc[1]),'p':float(res.pvalues[term]),'n_samples':len(frame),'n_patients':frame.donor.nunique()}
res,main=fit(d);print('PRIMARY '+json.dumps(main),flush=True)
sens=[];complete=d.groupby('donor').size();dc=d[d.donor.isin(complete[complete==4].index)].copy();_,v=fit(dc);v['label']='complete_four_visits';sens.append(v)
for proxy in ['MONO_PROXY','T_PROXY']:decompose(d,proxy)
_,v=fit(d,' + MONO_PROXY_within10 + MONO_PROXY_between + T_PROXY_within10 + T_PROXY_between');v['label']='marker_proxy_adjusted';sens.append(v)
fe=smf.ols('OXPHOS ~ IFNA_within10 + C(visit) + C(donor)',d).fit(cov_type='cluster',cov_kwds={'groups':d.donor,'use_correction':True},use_t=True)
sens.append(olsresult(fe,'IFNA_within10',d,'patient_fixed_effects_clustered'))
wide=d[d.visit.isin(['D0','M6'])].pivot(index='donor',columns='visit',values=['IFNA','OXPHOS']).dropna()
paired=pd.DataFrame({'donor':wide.index,'deltaIFNA10':(wide['IFNA']['M6']-wide['IFNA']['D0']).to_numpy()/.1,
                     'deltaOXPHOS':(wide['OXPHOS']['M6']-wide['OXPHOS']['D0']).to_numpy(),
                     'baselineIFNA':wide['IFNA']['D0'].to_numpy(),'baselineOXPHOS':wide['OXPHOS']['D0'].to_numpy()})
pairres=smf.ols('deltaOXPHOS ~ deltaIFNA10 + baselineIFNA + baselineOXPHOS',paired).fit(cov_type='HC3',use_t=True)
sens.append(olsresult(pairres,'deltaIFNA10',paired,'paired_D0_M6_HC3'))
secondary=[]
for gene in ['IFI27','AHR']:
 if gene not in d.columns:secondary.append({'gene':gene,'status':'not_unambiguously_mapped'});continue
 d[gene+'_between']=d.groupby('donor')[gene].transform('mean');d[gene+'_within']=d[gene]-d[gene+'_between']
 fitg=smf.ols(f'OXPHOS ~ {gene}_within + C(visit) + C(donor)',d).fit(cov_type='cluster',cov_kwds={'groups':d.donor,'use_correction':True},use_t=True)
 q=olsresult(fitg,gene+'_within',d,gene);q['gene']=gene;q['unit']='OXPHOS score per 1 log2-expression unit';secondary.append(q)
valid=[q for q in secondary if 'p' in q]
for q,bh in zip(valid,multipletests([q['p'] for q in valid],method='fdr_bh')[1]):q['p_BH_two_gene_family']=float(bh)
meta.to_csv(out/'ALL_SAMPLE_SCORES.csv',encoding='utf-8-sig');d.to_csv(out/'PRIMARY_SCORES_LOCAL.csv',encoding='utf-8-sig')
res.summary().as_text();(out/'PRIMARY_MODEL.txt').write_text(res.summary().as_text(),encoding='utf-8')
trajectory=[]
for visit in ['D0','discharge','M1','M6']:
 f=d[d.visit==visit];row={'visit':visit,'n_patients':f.donor.nunique()}
 for nm in ['IFNA','OXPHOS']:row[nm+'_mean']=float(f[nm].mean());row[nm+'_sd']=float(f[nm].std());row[nm+'_median']=float(f[nm].median())
 trajectory.append(row)
hf=[]
for group in ['HF','non-HF']:
 donors=meta[(meta.hf_progression==group)&(meta.group=='STEMI')].donor.unique()
 for visit in ['D0','discharge','M1','M6']:
  f=d[(d.donor.isin(donors))&(d.visit==visit)];hf.append({'group':group,'visit':visit,'n_patients':f.donor.nunique(),'IFNA_mean':float(f.IFNA.mean()),'OXPHOS_mean':float(f.OXPHOS.mean())})
results={'date':'2026-10-04','protocol_version':'frozen-1','primary':main,'sensitivity':sens,'secondary':secondary,'trajectory':trajectory,'HF_descriptive':hf,
 'overlap_sensitivity':{'shared_genes':[],'identical_to_primary':True,'reason':'No target gene overlap; not an additional independent result'},
 'validation':'GSE123342 HOLD: missing donor key and unmatched matrix/platform probe IDs','bootstrap':'running','random_control':'running'}
def save():
 (out/'RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
save()
# Fixed patient/time residualization for matched-random-set scoring diagnostic.
indices=expr.columns.get_indexer(d.index);ranksub=ranks[:,indices]
Z=np.column_stack([np.ones(len(d)),pd.get_dummies(d.donor,drop_first=True,dtype=float).to_numpy(),pd.get_dummies(d.visit,drop_first=True,dtype=float).to_numpy()])
Q=np.linalg.qr(Z,mode='reduced')[0]
def resid(x):return x-Q@(Q.T@x)
def fecoef(x,y):
 a=resid(x/.1);b=resid(y);return float(a@b/(a@a))
assert np.allclose(fecoef(d.IFNA.to_numpy(),d.OXPHOS.to_numpy()),fe.params['IFNA_within10'],rtol=1e-7)
rng=np.random.default_rng(SEED);means=expr.loc[:,d.index].mean(axis=1).to_numpy();bins=pd.qcut(means,10,labels=False,duplicates='drop')
exclude=set(sets['IFNA']['measured_genes'])|set(sets['OXPHOS']['measured_genes']);pools={k:np.flatnonzero((bins==k)&~expr.index.isin(exclude)) for k in range(10)}
def random_set(target):
 ids=expr.index.get_indexer(target);outids=[]
 for k in range(10):outids.extend(rng.choice(pools[k],size=int(np.sum(bins[ids]==k)),replace=False).tolist())
 return np.array(outids,dtype=int)
random=[]
for k in range(100):
 a=random_set(sets['IFNA']['measured_genes']);b=random_set(sets['OXPHOS']['measured_genes'])
 x=(ranksub[a].mean(axis=0)-(len(a)+1)/2)/(N-len(a))-.5;y=(ranksub[b].mean(axis=0)-(len(b)+1)/2)/(N-len(b))-.5
 random.append(fecoef(x,y))
actual=fecoef(d.IFNA.to_numpy(),d.OXPHOS.to_numpy());random=np.array(random)
results['random_control']={'n_pairs':100,'seed':SEED,'matching':'Same set sizes and counts in deciles of mean expression in primary samples; target genes excluded from sampling pools; sets sampled independently',
 'observed_fixed_effect_beta':actual,'median':float(np.median(random)),'q025':float(np.quantile(random,.025)),'q975':float(np.quantile(random,.975)),
 'fraction_abs_beta_at_least_observed':float(np.mean(np.abs(random)>=abs(actual))),'interpretation':'Scoring specificity diagnostic, not clinical validation or a confirmatory hypothesis P value'}
pd.DataFrame({'pair':range(1,101),'beta':random}).to_csv(out/'RANDOM_CONTROL_SLOPES.csv',index=False)
save();print('RANDOM '+json.dumps(results['random_control']),flush=True)
# Resample whole patients with replacement. Give duplicate sampled trajectories unique clusters.
rng=np.random.default_rng(SEED);donors=d.donor.unique();frames={u:d[d.donor==u].copy() for u in donors};boots=[];fails=[]
for k in range(200):
 chosen=rng.choice(donors,size=len(donors),replace=True);ff=[]
 for j,u in enumerate(chosen):
  f=frames[u].copy();f['donor']=str(j);ff.append(f)
 b=pd.concat(ff,ignore_index=True)
 try:_,v=fit(b);boots.append(v['beta'])
 except Exception as e:fails.append({'replicate':k+1,'error':str(e)})
 if (k+1)%25==0:print(f'BOOT {k+1}/200 success={len(boots)}',flush=True)
results['bootstrap']={'planned':200,'successful':len(boots),'failed':len(fails),'failures':fails,'seed':SEED,
 'median_beta':float(np.median(boots)),'ci_low':float(np.quantile(boots,.025)),'ci_high':float(np.quantile(boots,.975)),'unit':'same as primary','method':'Whole-patient resampling; repeated draws assigned new patient clusters; percentile interval'}
pd.DataFrame({'beta':boots}).to_csv(out/'PATIENT_BOOTSTRAP.csv',index=False)
save();print('DONE '+json.dumps(results['bootstrap'],ensure_ascii=False),flush=True)

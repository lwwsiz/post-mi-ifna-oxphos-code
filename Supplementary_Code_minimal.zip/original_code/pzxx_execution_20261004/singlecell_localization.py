"""Prespecified coarse marker-defined PBMC lineage context, donor-level summaries only."""
from pathlib import Path
import sys,json,gzip,tarfile,io,datetime,hashlib
O=Path(__file__).resolve().parent;sys.path.insert(0,str(O/'_deps'))
import numpy as np,pandas as pd
from scipy.io import mmread
from scipy.stats import rankdata
sys.stdout.reconfigure(encoding='utf-8');out=O/'singlecell';out.mkdir(exist_ok=True)
panels={'monocyte_like':['LYZ','CD14','FCGR3A','MS4A7'],'T_like':['CD3D','CD3E','TRAC'],
 'B_like':['MS4A1','CD79A','CD79B'],'NK_like':['NKG7','GNLY','KLRD1']}
spec={'frozen_before_lineage_program_effects':True,'date':'2026-10-04','source':'GSE269269; 10 donors; original Qian 2022 methods/correction 2024',
 'QC':'Nonzero UMI; at least 200 detected genes (secondary QC rule); mitochondrial UMI fraction <=25% (original reported rule). No arbitrary maximum gene filter; doublets not formally identified.',
 'annotation':'Coarse marker-defined compartments, not reproduced author/SingleR annotations. UMI-positive for >=2 panel genes. Monocyte additionally LYZ-positive. NK additionally zero T-panel genes. Exactly one positive compartment required; none=unassigned; multiple=ambiguous. Marker dropout and doublets remain limits.',
 'panels':panels,'scope':'Localization of relative transcriptional program scores across donor pseudobulks; no healthy controls, longitudinal inference, PR/NPR differential test or claim of cardiac macrophages.',
 'score':'Sum raw UMIs by donor and compartment; rank-based up-directed singscore. Fixed gene universe equals bulk measured HGNC genes intersect scRNA measured approved gene symbols; zero-count genes retained, tied ranks. Same gene universe and gene sets across compartments; cell-level scores not used as independent replicates.',
 'comparison':'Descriptive donor-level lineage contrasts only; all donors retained; report cell counts and undefined compartments; no 50-cell hard threshold. Scores across platforms not directly calibrated.',
 'nonprimary':'Implementation/QC frozen after primary bulk effects; this supporting cell localization is exploratory and cannot independently validate longitudinal bulk result.'}
path=out/'PROTOCOL_SINGLECELL.json'
if path.exists():raise RuntimeError('Single-cell plan already frozen; do not silently rerun/overwrite')
path.write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
sets=json.loads((O/'GENE_SETS_FROZEN.json').read_text(encoding='utf-8'));bulk=pd.read_pickle(O/'BULK_GENE_EXPRESSION.pkl').index
target=set(sets['IFNA']['declared_genes'])|set(sets['OXPHOS']['declared_genes'])
assert not target.intersection(g for p in panels.values() for g in p), 'Annotation marker overlaps target set'
rows=[];qc=[];markers=[];exprs={};features0=None
with tarfile.open(O/'inputs/GSE269269_RAW.tar','r') as tar:
 mats=sorted([m for m in tar.getmembers() if m.name.endswith('matrix.mtx.gz')],key=lambda m:m.name)
 for mem in mats:
  prefix=mem.name.removesuffix('matrix.mtx.gz');donor=prefix.split('_')[1];group='NPR' if donor.startswith('NPR') else 'PR'
  feat=gzip.decompress(tar.extractfile(prefix+'features.tsv.gz').read()).decode().splitlines()
  syms=np.array([x.split('\t')[1] for x in feat]);indices={s:np.flatnonzero(syms==s) for s in set(syms)}
  if features0 is None:features0=syms;universe=np.array([s for s in bulk if s in indices and len(indices[s])==1]);uid=np.array([indices[s][0] for s in universe])
  else:assert np.array_equal(features0,syms)
  mat=mmread(gzip.GzipFile(fileobj=tar.extractfile(mem))).tocsr();tot=np.asarray(mat.sum(axis=0)).ravel();ng=np.asarray((mat>0).sum(axis=0)).ravel()
  mit=np.asarray(mat[np.char.startswith(syms.astype(str),'MT-')].sum(axis=0)).ravel();frac=np.divide(mit,tot,out=np.ones_like(tot,dtype=float),where=tot>0)
  keep=(tot>0)&(ng>=200)&(frac<=.25);mat=mat[:,keep].tocsc();nc=mat.shape[1]
  det={name:np.asarray((mat[np.array([indices[g][0] for g in genes])] >0).sum(axis=0)).ravel() for name,genes in panels.items()}
  cand={name:det[name]>=2 for name in panels};cand['monocyte_like']&=np.asarray(mat[indices['LYZ'][0]].toarray()).ravel()>0
  cand['NK_like']&=det['T_like']==0
  allcand=np.vstack(list(cand.values()));ncan=allcand.sum(axis=0);label=np.full(nc,'unassigned',dtype=object);label[ncan>1]='ambiguous'
  for name,v in cand.items():label[v&(ncan==1)]=name
  counts={name:int(np.sum(label==name)) for name in list(panels)+['unassigned','ambiguous']}
  qc.append({'donor':donor,'group':group,'raw_cells':len(tot),'retained_cells':nc,'removed_cells':len(tot)-nc,'median_detected_genes':float(np.median(ng[keep])),'median_UMI':float(np.median(tot[keep])),**counts})
  for name in panels:
   select=label==name;nn=int(select.sum())
   if not nn:continue
   pseud=np.asarray(mat[uid][:,select].sum(axis=1)).ravel();exprs[(donor,name)]=pseud
   ranks=rankdata(pseud,method='average');nr=len(universe);row={'donor':donor,'group':group,'lineage':name,'cells':nn,'total_UMI':int(pseud.sum())}
   for nm in ['IFNA','OXPHOS']:
    members=sorted(set(sets[nm]['declared_genes'])&set(universe));ii=pd.Index(universe).get_indexer(members);m=len(ii)
    row[nm]=(float(ranks[ii].mean())-(m+1)/2)/(nr-m)-.5;row[nm+'_genes']=m
   rows.append(row)
   for pn,genes in panels.items():
    for g in genes:
     rate=float(np.mean(np.asarray(mat[indices[g][0]][:,select].toarray()).ravel()>0));markers.append({'donor':donor,'lineage':name,'gene':g,'positive_fraction':rate})
  print(f'{donor}: raw={len(tot)} QC={nc} compartments={counts}',flush=True)
pd.DataFrame(rows).to_csv(out/'DONOR_LINEAGE_PSEUDOBULK_LOCAL.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(qc).to_csv(out/'QC_BY_DONOR.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(markers).to_csv(out/'MARKER_DETECTION_LOCAL.csv',index=False,encoding='utf-8-sig')
df=pd.DataFrame(rows);summary=[]
for lineage in panels:
 f=df[df.lineage==lineage];row={'lineage':lineage,'n_donors':len(f),'cells_total':int(f.cells.sum()),'cells_min':int(f.cells.min()),'cells_max':int(f.cells.max())}
 for nm in ['IFNA','OXPHOS']:row[nm+'_mean']=float(f[nm].mean());row[nm+'_sd']=float(f[nm].std());row[nm+'_median']=float(f[nm].median())
 summary.append(row)
report={'status':'EXPLORATORY_MARKER_DEFINED_LOCALIZATION','raw_cells':sum(r['raw_cells'] for r in qc),'retained_cells':sum(r['retained_cells'] for r in qc),
 'assigned_cells':int(sum(r['cells'] for r in rows)),'unassigned_cells':sum(r['unassigned'] for r in qc),'ambiguous_cells':sum(r['ambiguous'] for r in qc),
 'gene_universe':len(universe),'target_gene_coverage':{nm:len(set(sets[nm]['declared_genes'])&set(universe)) for nm in ['IFNA','OXPHOS']},'summary':summary,
 'annotation_boundary':'No deposited cell labels; deterministic broad marker gates; ambiguous cells excluded; annotation accuracy not externally measured. No cardiac macrophage, cell-state mechanism or independent longitudinal-validation inference.'}
(out/'SUMMARY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))

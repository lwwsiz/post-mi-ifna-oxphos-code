"""Map primary expression without effect calculation, freeze predeclared analysis specification."""
from pathlib import Path
import collections,csv,gzip,hashlib,json,sys,datetime
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'_deps'))
import numpy as np,pandas as pd
sys.stdout.reconfigure(encoding='utf-8')
RAW=OUT/'inputs'; PREP=OUT.parent/'pzxx_sustainable_plan_20261004'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def matrix(p):
 with gzip.open(p,'rt',encoding='utf-8') as f:
  for line in f:
   if line.startswith('!series_matrix_table_begin'):break
  data=pd.read_csv(f,sep='\t',index_col=0,dtype={0:str})
 data=data.loc[~data.index.astype(str).str.startswith('!')]
 return data.apply(pd.to_numeric,errors='coerce')
def annotation(p):
 with gzip.open(p,'rt',encoding='utf-8') as f:
  for line in f:
   if line.startswith('!platform_table_begin'):break
  frame=pd.read_csv(f,sep='\t',dtype=str,keep_default_na=False)
 return frame.loc[~frame['ID'].str.startswith('!')]
hgnc=pd.read_csv(RAW/'hgnc_complete_set_20261004.txt',sep='\t',dtype=str,keep_default_na=False)
approved=set(hgnc['symbol'])
aliases=collections.defaultdict(set)
for _,r in hgnc.iterrows():
 for field in ['prev_symbol','alias_symbol']:
  for alias in r[field].split('|'):
   if alias: aliases[alias].add(r['symbol'])
def current_symbol(s):
 if s in approved:return s
 targets=aliases.get(s,set())
 return next(iter(targets)) if len(targets)==1 else None
raw=matrix(RAW/'GSE59867_series_matrix.txt.gz')
ann=annotation(RAW/'GPL6244.annot.gz')
mapped=[]
for _,r in ann.iterrows():
 symbols={current_symbol(s.strip()) for s in r['Gene symbol'].split('///') if s.strip()}
 symbols.discard(None)
 if len(symbols)==1: mapped.append({'probe':r['ID'],'gene':next(iter(symbols))})
map_df=pd.DataFrame(mapped).drop_duplicates('probe')
common=map_df[map_df['probe'].isin(raw.index)]
data=raw.loc[common['probe']].copy();data.index=common['gene'].to_numpy()
genes=data.groupby(level=0,sort=True).median()
genes.to_pickle(OUT/'BULK_GENE_EXPRESSION.pkl')
common.to_csv(OUT/'PROBE_GENE_MAP.csv',index=False,encoding='utf-8-sig')
metadata=pd.read_csv(PREP/'SAMPLE_MANIFEST.csv',keep_default_na=False)
meta=metadata[metadata['series']=='GSE59867'].set_index('sample').loc[genes.columns]
meta.to_csv(OUT/'PRIMARY_METADATA.csv',encoding='utf-8-sig')
sets={}
for n,f in [('IFNA','Hallmark_IFNA.json'),('OXPHOS','Hallmark_OXPHOS.json')]:
 obj=json.loads((RAW/f).read_text(encoding='utf-8'))
 original=next(iter(obj.values()))['geneSymbols']
 members=sorted(set(current_symbol(g) for g in original)-{None})
 measured=sorted(set(members)&set(genes.index))
 sets[n]={'name':next(iter(obj)),'declared_genes':members,'measured_genes':measured,'missing':sorted(set(members)-set(measured)),
          'snapshot':'official download 2026-10-04; release number not supplied in JSON','source_sha256':digest(RAW/f)}
sets['MONO_PROXY']={'measured_genes':['CD14','LYZ','FCGR3A','MS4A7']}
sets['T_PROXY']={'measured_genes':['CD3D','CD3E','TRAC']}
for n in ['MONO_PROXY','T_PROXY']:
 sets[n]['measured_genes']=[g for g in sets[n]['measured_genes'] if g in genes.index and g not in set(sets['IFNA']['measured_genes'])|set(sets['OXPHOS']['measured_genes'])]
overlap=sorted(set(sets['IFNA']['measured_genes'])&set(sets['OXPHOS']['measured_genes']))
summary={'date':'2026-10-04','raw_probes':len(raw),'samples':raw.shape[1],'unique_unambiguously_mapped_genes':len(genes),
         'mapped_probes':len(common),'nonfinite_values':int((~np.isfinite(genes.to_numpy())).sum()),
         'expression_quantiles':np.quantile(genes.to_numpy(),[0,.01,.5,.99,1]).tolist(),
         'log_transform':'Already RMA/log2 processed in original study; no second log2 or new quantile normalization.',
         'probe_aggregation':'Median over probes mapping to exactly one approved HGNC gene after unambiguous symbol normalization; no choice by effect/variance.',
         'sets':{n:{'measured':len(v['measured_genes']),'missing':v.get('missing',[])} for n,v in sets.items()},'shared_target_genes':overlap,
         'input_sha256':{f:digest(RAW/f) for f in ['GSE59867_series_matrix.txt.gz','GPL6244.annot.gz','hgnc_complete_set_20261004.txt','Hallmark_IFNA.json','Hallmark_OXPHOS.json']}}
if summary['nonfinite_values'] or raw.shape[1]!=436:raise RuntimeError('primary source QC requires audit')
if len(sets['IFNA']['measured_genes'])<70 or len(sets['OXPHOS']['measured_genes'])<150:raise RuntimeError('gene-set measurement incomplete; no effects; coverage audit required')
(OUT/'PRIMARY_INPUT_QC.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'GENE_SETS_FROZEN.json').write_text(json.dumps(sets,ensure_ascii=False,indent=2),encoding='utf-8')
protocol=json.loads((PREP/'PROTOCOL_DRAFT.json').read_text(encoding='utf-8'))
protocol.update(version='frozen-1',frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen=True,effects_previously_computed=False)
protocol['authorization']['specific_formal_analysis_confirmation']='2026-10-04 user: 确认，连续推进至可审阅投稿包'
protocol['set_version_and_hash']=summary['input_sha256']
protocol['implemented_specification']={
 'gene_universe':'All uniquely HGNC-mapped measured genes; identical universe for all GSE59867 samples',
 'score_formula':'Average-tie increasing ranks; up-directed score=(mean_rank-(m+1)/2)/(N-m)-0.5',
 'primary_effect_unit':'OXPHOS raw singscore per 0.1-unit within-person IFNA score; report scaled slope and 95% CI',
 'fit':'REML random patient intercept; within/between IFNA decomposition and categorical time. Optimize lbfgs then Powell if convergence fails, no model replacement by significance.',
 'random_effect_boundary':'If singular boundary, transparently retain boundary result and patient-clustered fixed-patient regression sensitivity; do not invent convergence.',
 'primary_exclusion':'Only missing donor/visit, absent primary scores, duplicate patient-visit or nonfinite expression. Do not delete PCA outliers by association; display PCA QC separately.',
 'sensitivity':['83 D0/M6 donors, delta slope with baseline IFNA and OXPHOS adjustment','73 complete 4-visit donors, same model','Patient fixed effects plus visit, patient-clustered SE','Primary model plus prespecified monocyte and T-marker scores (not measured proportions)','Two target scores recalculated after removing shared genes, same model','200 patient-resampling fits and percentile interval; seed=20261004','100 expression-mean/size-matched random gene-set pairs, within/time fixed-effects slopes as scoring-specificity diagnostic; seed=20261004, not clinical validation'],
 'secondary':'IFI27 and AHR within-person slopes with time adjustment, BH family of these 2 tests only; descriptive original HF9/nonHF8. No ROC/prediction.',
 'cell_type_panels':'Use original Qian publication markers and measured gene coverage; donor-aware lineage localization only. 10-donor study lacks healthy control/follow-up.',
 'replication_gate':'GSE123342 longitudinal computation only if original patient key and matching platform IDs established; if not, missing-validation boundary retained.',
 'null_and_precision':'All signs/CIs/diagnostics reported. No discovery threshold requires positive P; publication adequacy judged separately.'}
(OUT/'PROTOCOL_FROZEN.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))

"""Integrity and aggregate arithmetic only; no fitting or patient data."""
from pathlib import Path
import json, csv, hashlib, math
R=Path(__file__).resolve().parent
load=lambda n:json.loads((R/'aggregate_outputs'/n).read_text('utf8'))
checks=[]
def check(name,ok,detail=None):
 checks.append({'name':name,'passed':bool(ok),'detail':detail})
def near(name,a,b,tol=1e-10):check(name,math.isclose(a,b,rel_tol=tol,abs_tol=tol),{'calculated':a,'frozen':b})
for rel,info in json.loads((R/'MANIFEST_SHA256.json').read_text('utf8')).items():
 p=R/rel
 check('sha256:'+rel,p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256'])
u=load('RESULTS_UPGRADE.json');c=load('CLINICAL_RESULTS_AGGREGATE.json')
p=u['V1_primary_retained']
near('primary z=beta/SE',p['beta']/p['se'],p['z'])
check('primary cohort',u['n_patients']==108 and u['n_samples']==387)
rows=list(csv.DictReader((R/'aggregate_outputs/PATIENT_STANDARDIZED_BOOTSTRAP.csv').open(encoding='utf8')))
def quant(values,q):
 a=sorted(values);pos=(len(a)-1)*q;i=math.floor(pos);j=math.ceil(pos)
 return a[i]+(a[j]-a[i])*(pos-i)
check('bootstrap rows',len(rows)==1000)
vals=[float(x['IFNA_OXPHOS_r']) for x in rows]
near('IFNA bootstrap lower',quant(vals,.025),u['standardized_association']['ci_low'])
near('IFNA bootstrap upper',quant(vals,.975),u['standardized_association']['ci_high'])
m=u['matched_random_diagnostic'];n=m['n_pairs'];k=m['exceeding_pairs'];frac=k/n
random_rows=list(csv.DictReader((R/'aggregate_outputs/MATCHED_RANDOM_PAIR_DIAGNOSTICS.csv').open(encoding='utf8')))
check('random pair rows',len(random_rows)==n)
check('random exceeding count from CSV',sum(abs(float(x['r']))>=abs(u['standardized_association']['r']) for x in random_rows)==k)
near('random exceeding fraction',frac,m['fraction_abs_random_r_at_least_target'])
z=1.959963984540054;den=1+z*z/n;mid=(frac+z*z/(2*n))/den
half=z*math.sqrt(frac*(1-frac)/n+z*z/(4*n*n))/den
near('random Wilson lower',mid-half,m['Monte_Carlo_Wilson95'][0])
near('random Wilson upper',mid+half,m['Monte_Carlo_Wilson95'][1])
check('clinical individual rows excluded',c['individual_rows_in_this_aggregate_file'] is False)
check('clinical sample size',c['patient_n']==32)
for item in c['primary']:
 near('clinical '+item['exposure']+' t=beta/HC3SE',item['beta_LVEF_percentage_points_per_selected_sample_SD']/item['HC3_SE'],item['t_statistic'])
ind=load('NUMERICAL_COMPARISON_FINAL.json')
check('completed independent clinical comparison',ind['exact_failed_n']==0 and not ind['mismatches'])
# Paired differences are recomputed from the delivered replicate correlations.
d=[float(x['IFNA_OXPHOS_r'])-float(x['IFNG_OXPHOS_r']) for x in rows]
paired={'point':u['standardized_association']['r']-u['inflammatory_references'][0]['r'],'lower':quant(d,.025),'upper':quant(d,.975)}
frozen_pair=load('D_BULK_ADDITIONS_RESULTS.json')['IFNA_IFNG_direct_difference']
for key,fkey in [('point','delta'),('lower','ci_low'),('upper','ci_high')]:
 near('paired difference '+key,paired[key],frozen_pair[fkey])
out={'scope':'Archive integrity and frozen aggregate arithmetic; no raw matrix refit, model selection or biological validation.','checks':checks,'check_count':len(checks),'failed':sum(not x['passed'] for x in checks),'paired_difference_recomputed':paired,'status':'PASS' if all(x['passed'] for x in checks) else 'FAIL'}
(R/'AGGREGATE_VERIFICATION.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps({'status':out['status'],'check_count':out['check_count'],'failed':out['failed']}))
if out['failed']:raise SystemExit(1)
